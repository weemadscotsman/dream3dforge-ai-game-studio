import { localAI } from "./localModelService";

// --- 1. Strict Types ---

export type ProviderID = "openrouter" | "openai" | "google" | "ollama";

export interface ProviderConfig {
  id: ProviderID;
  endpoint: string; // Full URL including /chat/completions
  model: string;
  apiKey?: string;
  headers?: Record<string, string>;
}

export interface LLMResponse {
  text: string | undefined;
}

// --- 2. Resolution Logic (No Fallbacks) ---

function resolveProvider(): ProviderConfig {
  if (typeof localStorage === 'undefined') {
    // Build-time / Server-side safety
    return { id: 'ollama', endpoint: 'http://localhost:11434/v1/chat/completions', model: 'llama3' };
  }

  const rawSettings = localStorage.getItem("dream3dforge.settings");
  if (!rawSettings) {
    // Return a dummy config that prompts for setup
    return { id: 'openai', endpoint: 'UNCONFIGURED', model: 'unconfigured', apiKey: '' };
  }
  const settings = JSON.parse(rawSettings);
  const active = settings.provider;

  if (active === "openrouter") {
    // OpenRouter: Meta-Provider
    const key = settings.openRouterKey;
    if (!key) throw new Error("CRITICAL: OpenRouter selected but no API Key found.");

    return {
      id: "openrouter",
      endpoint: "https://openrouter.ai/api/v1/chat/completions",
      model: settings.openRouterModel || "preferred-reasoning-model",
      apiKey: key,
      headers: {
        "HTTP-Referer": "https://dream3dforge.app",
        "X-Title": "CANN.ON.AI SYSTEMS"
      }
    };
  }

  if (active === "openai") {
    // OpenAI: Standard
    const key = settings.openAIKey;
    if (!key) throw new Error("CRITICAL: OpenAI selected but no API Key found.");

    return {
      id: "openai",
      endpoint: "https://api.openai.com/v1/chat/completions",
      model: "gpt-4o",
      apiKey: key
    };
  }

  if (active === "ollama") {
    // CANN.ON.AI - Local Sovereignty
    const baseUrl = settings.ollamaEndpoint || "http://localhost:11434";
    // We update the service singleton just in case
    localAI.setHost(baseUrl);

    return {
      id: "ollama",
      endpoint: baseUrl,
      model: settings.ollamaModel || "llama3", // User standard
      apiKey: "ollama"
    };
  }

  if (active === "google" || active === "gemini") {
    const key = settings.geminiKey || (import.meta as any).env.VITE_GEMINI_API_KEY;
    if (!key) throw new Error("CRITICAL: Google Gemini selected but no API Key found.");

    return {
      id: "google",
      endpoint: "SDK_INTERNAL",
      model: settings.geminiModel || "gemini-2.5-pro",
      apiKey: key
    };
  }

  throw new Error(`CRITICAL: No valid provider configured. Active: ${active}`);
}

// --- 3. Probe & Negotiation Logic ---

// Cache implementation
const MODEL_CACHE_KEY = "d3d_model_cache";
const CACHE_TTL = 1000 * 60 * 60; // 1 hour

interface ModelCache {
  timestamp: number;
  models: { id: string; context: number; provider: string }[];
}

function loadModelCache(): ModelCache | null {
  if (typeof localStorage === 'undefined') return null;
  const raw = localStorage.getItem(MODEL_CACHE_KEY);
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw);
    if (Date.now() - parsed.timestamp > CACHE_TTL) return null;
    return parsed;
  } catch { return null; }
}

function saveModelCache(models: any[]) {
  if (typeof localStorage === 'undefined') return;
  localStorage.setItem(MODEL_CACHE_KEY, JSON.stringify({
    timestamp: Date.now(),
    models
  }));
}

// OpenRouter specific probe
export async function probeOpenRouterModels(apiKey: string) {
  const cached = loadModelCache();
  if (cached) return cached.models;

  console.log("[AI Probe] Fetching OpenRouter model list...");
  try {
    const res = await fetch("https://openrouter.ai/api/v1/models", {
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "HTTP-Referer": "https://dream3dforge.app",
        "X-Title": "Dream3DForge"
      }
    });

    if (!res.ok) return null;

    const data = await res.json();
    const models = data.data.map((m: any) => ({
      id: m.id,
      name: m.name,
      context: m.context_length,
      pricing: {
        prompt: parseFloat(m.pricing.prompt),
        completion: parseFloat(m.pricing.completion)
      }
    }));

    saveModelCache(models);
    return models;
  } catch { return null; }
}

const MODEL_TAGS: Record<string, (models: any[]) => string> = {
  "preferred-reasoning-model": (models) => {
    // Intelligent filtering: Find high-IQ but cost-efficient models
    // Priority: 1. Claude 3.5 Sonnet, 2. GPT-4o, 3. DeepSeek-V3/R1 (if available), 4. Gemini 1.5 Pro
    const highTier = [
      "anthropic/claude-3.5-sonnet",
      "openai/gpt-4o",
      "deepseek/deepseek-chat",
      "deepseek/deepseek-r1",
      "google/gemini-pro-1.5"
    ];
    const found = highTier.find(id => models.some(m => m.id === id));
    if (found) return found;

    const sorted = models
      .filter(m => m.context >= 65536 && (m.id.includes("pro") || m.id.includes("sonnet") || m.id.includes("gpt-4")))
      .sort((a, b) => (a.pricing.prompt + a.pricing.completion) - (b.pricing.prompt + b.pricing.completion));
    return sorted[0]?.id || "openai/gpt-3.5-turbo";
  },
  "preferred-fast-model": (models) => {
    // Speed/Cost optimization: Prefer 4o-mini or Flash
    const fastTier = ["openai/gpt-4o-mini", "google/gemini-flash-1.5", "anthropic/claude-3-haiku"];
    const found = fastTier.find(id => models.some(m => m.id === id));
    if (found) return found;

    const sorted = models.sort((a, b) => a.pricing.prompt - b.pricing.prompt);
    return sorted[0]?.id || "openai/gpt-3.5-turbo";
  },
  "kimi": (models) => {
    // Force Kimi model selection
    const kimiModels = [
      "moonshotai/kimi-k2.5",
      "moonshotai/kimi-k2", 
      "moonshotai/kimi-k1.5",
      "moonshotai/kimi-latest"
    ];
    const found = kimiModels.find(id => models.some(m => m.id === id));
    if (found) return found;
    return "moonshotai/kimi-k2.5"; // Default to K2.5
  }
};

async function probeSpecificModel(provider: ProviderConfig): Promise<boolean> {
  if (provider.id === 'google') return true;
  if (provider.id === 'ollama') return true;

  if (provider.id === 'openrouter' && provider.apiKey) {
    const models = await probeOpenRouterModels(provider.apiKey);
    if (models) {
      return models.some((m: any) => m.id === provider.model);
    }
  }

  try {
    const headers: Record<string, string> = { "Content-Type": "application/json", ...(provider.headers || {}) };
    if (provider.apiKey) headers["Authorization"] = `Bearer ${provider.apiKey}`;

    const res = await fetch(provider.endpoint, {
      method: "POST", headers,
      body: JSON.stringify({ model: provider.model, messages: [{ role: "user", content: "ping" }], max_tokens: 1 })
    });
    return res.status !== 404;
  } catch { return false; }
}

async function negotiateClient(config: any): Promise<ProviderConfig> {
  let provider = resolveProvider();
  const requestedModel = config.model || provider.model;

  // If it's a semantic tag, resolve it via OpenRouter list if active
  if (provider.id === "openrouter" && MODEL_TAGS[requestedModel]) {
    const models = await probeOpenRouterModels(provider.apiKey!);
    if (models) {
      const resolved = MODEL_TAGS[requestedModel](models);
      console.log(`[AI Negotiation] Resolved ${requestedModel} -> ${resolved}`);
      provider.model = resolved;
      return provider;
    }
  }

  // Otherwise, honor the requested model if it's not a tag
  if (requestedModel && !MODEL_TAGS[requestedModel]) {
    provider.model = requestedModel;
    // Skip probe for explicit model IDs (they contain "/" like "moonshotai/kimi-k2.5")
    if (requestedModel.includes('/')) return provider;
  }

  // Final check
  if (await probeSpecificModel(provider)) return provider;

  throw new Error(`CRITICAL: Negotiation failed. No valid models found for ${provider.id}.`);
}


// --- 4. Execution Logic (Unified) ---

export const getAIClient = () => {
  return {
    generateContent: async (config: any): Promise<LLMResponse> => {
      // Resolve AND Negotiate
      // Note: In a high-traffic app we would cache the negotiated result. 
      // Here we do it per-call or could cache it in a module-level variable.
      // For safety in this "Fix" phase, we run it. To optimize, we can cache.

      // Optimization: If NOT OpenRouter, skip negotiation for speed unless user flagged.
      // But User requested PROBE. So we probe.

      const provider = await negotiateClient(config);

      if (provider.endpoint === 'UNCONFIGURED') {
        throw new Error("AI SETUP REQUIRED: Please open Settings (Gear icon) to configure your AI provider (Gemini, OpenAI, or Local Ollama).");
      }

      console.log(`[AI] Executing via ${provider.id} (${provider.model})`);

      // 1. CANN.ON.AI LOCAL SOVEREIGNTY MODE
      if (provider.id === 'ollama') {
        const rawSettings = localStorage.getItem("dream3dforge.settings");
        const isSovereign = rawSettings ? JSON.parse(rawSettings).useSovereignStack : false;

        if (isSovereign) {
          const { localRouter } = await import("./localLLMRouter");
          // Use orchestration for high-level tasks if we can identify them
          // For generic generateContent, we'll use a conservative 'reasoning' mapping
          const text = await localRouter.routeToModel('reasoning', config.contents);
          return { text };
        }

        return await localAI.generateContent({
          model: provider.model,
          contents: config.contents,
          config: config.config
        });
      }

      // SPECIAL CASE: Google SDK (Legacy Isolation)
      if (provider.id === 'google') {
        // Lazy load SDK to prevent pollution elsewhere
        const { GoogleGenAI } = await import("@google/genai");
        const client = new GoogleGenAI({ apiKey: provider.apiKey! });

        // Clean model string if user passed namespace
        const modelId = provider.model; // Enforce safe default

        const safeConfig = { ...config };
        //thinkingConfig is only supported on specific models. Omit if not applicable.
        if (safeConfig.config?.thinkingConfig && !modelId.includes('thinking')) {
          delete safeConfig.config.thinkingConfig;
        }

        try {
          const response = await client.models.generateContent({
            ...safeConfig,
            model: modelId
          });
          const respAny = response as any;
          return { text: typeof respAny.text === 'function' ? respAny.text() : String(respAny.text) };
        } catch (e) {
          console.error("Gemini SDK Error:", e);
          throw e;
        }
      }

      // UNIFIED FETCH PATH (OpenAI / OpenRouter / Ollama)
      let promptText = "";
      if (typeof config.contents === 'string') {
        promptText = config.contents;
      } else if (Array.isArray(config.contents)) {
        promptText = config.contents[0]?.parts?.[0]?.text || "";
      } else if (config.parts?.[0]?.text) {
        // Fallback for simple object with parts
        promptText = config.parts[0].text;
      }

      // We use the NEGOTIATED model, ignoring the 'preferred-reasoning-model' hint
      // unless we want to strictly map it. But negotiation logic overrides for stability.
      const actualModel = provider.model;

      const headers: Record<string, string> = {
        "Content-Type": "application/json",
        ...(provider.headers || {})
      };

      if (provider.apiKey) {
        headers["Authorization"] = `Bearer ${provider.apiKey}`;
        console.log(`[AI] Using API key: ${provider.apiKey.substring(0, 10)}...`);
      } else {
        console.error("[AI] CRITICAL: No API key found for provider:", provider.id);
        throw new Error("API Key missing. Check settings.");
      }

      // Standard OpenAI Chat Completion Body
      const body = {
        model: actualModel,
        messages: [
          { role: "user", content: promptText }
        ],
        temperature: config.config?.temperature,
        max_tokens: config.config?.maxOutputTokens,
        stream: false
      };

      try {
        const res = await fetch(provider.endpoint, {
          method: "POST",
          headers,
          body: JSON.stringify(body)
        });

        if (!res.ok) {
          const errText = await res.text();
          // Hard error for 404
          if (res.status === 404) {
            // Should not happen if probe passed, but race conditions exist
            throw new Error(`CRITICAL: 404 Not Found at ${provider.endpoint}. Model '${actualModel}' failed during execution despite probe.`);
          }
          throw new Error(`Provider Error (${res.status}): ${errText}`);
        }

        const data = await res.json();
        return { text: data.choices?.[0]?.message?.content || "" };
      } catch (error) {
        console.error(`[AI] Request failed for ${provider.id}:`, error);
        throw error;
      }
    }
  };
};

// Legacy helper removed.

