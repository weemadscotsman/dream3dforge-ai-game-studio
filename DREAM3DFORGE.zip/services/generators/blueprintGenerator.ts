import { Type, Schema } from "../googleSchemaShim";
import { UserPreferences, GeneratedGame } from "../../types";
import { getAIClient } from "../client";
import { parseAndSanitize, validateStructure, retryWithBackoff } from "../utils/aiHelpers";
import { PromptRegistry } from "../promptRegistry";

// --- SCHEMA 1: QUANTIZED SPEC SHEET ---
const specSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING, description: "The title of the game (2-4 words)." },
    summary: { type: Type.STRING, description: "One sentence high concept pitch (max 20 words)." },
    coreMechanics: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "List of 3-5 specific gameplay mechanics."
    },
    visualRequirements: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "List of 3-5 specific visual targets."
    },
    // New Rich Fields
    gameLoop: {
      type: Type.OBJECT,
      properties: {
        setup: { type: Type.STRING, description: "Initial state and spawn logic" },
        action: { type: Type.STRING, description: "Core player vs environment interaction loop" },
        resolution: { type: Type.STRING, description: "Win/loss conditions and restart logic" }
      },
      required: ["setup", "action", "resolution"]
    },
    controls: {
      type: Type.OBJECT,
      properties: {
        scheme: { type: Type.STRING, description: "Mouse/Keyboard, Touch, etc." },
        mappings: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              input: { type: Type.STRING },
              action: { type: Type.STRING }
            },
            required: ["input", "action"]
          }
        }
      },
      required: ["scheme", "mappings"]
    },
    entities: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          behavior: { type: Type.STRING, description: "AI or physics logic" },
          attributes: { type: Type.STRING, description: "Speed, Health, etc." }
        },
        required: ["name", "behavior"]
      }
    },
    // ASSETS (Mandatory Deep Design)
    assets: {
      type: Type.OBJECT,
      properties: {
        textures: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              type: { type: Type.STRING, enum: ['pixel', 'grid', 'noise'] },
              params: { 
                type: Type.OBJECT,
                properties: {
                  color: { type: Type.STRING, description: "Primary color (hex or name)" },
                  size: { type: Type.NUMBER, description: "Texture size in pixels" },
                  pattern: { type: Type.STRING, description: "Pattern type (solid, gradient, checkered, etc.)" }
                }
              }
            },
            required: ["name", "type", "params"]
          }
        },
        models: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              type: { type: Type.STRING, enum: ['voxel'] },
              layers: { type: Type.ARRAY, items: { type: Type.STRING } }
            },
            required: ["name", "type", "layers"]
          }
        }
      },
      required: ["textures", "models"]
    },
    // GAMEPLAY MATH (Mandatory Deep Design)
    gameplayRules: {
      type: Type.OBJECT,
      properties: {
        movement: { type: Type.STRING, description: "Exact speeds, friction, jump heights (physically accurate values)" },
        combat: { type: Type.STRING, description: "Damage formulas, hitboxes, recoil values" },
        scoring: { type: Type.STRING, description: "Point values, combo multipliers" }
      },
      required: ["movement", "combat", "scoring"]
    },
    uiLayout: {
      type: Type.ARRAY,
      items: { type: Type.STRING, description: "List of HUD elements (Score, Health, etc.)" }
    }
  },
  required: ["title", "summary", "coreMechanics", "visualRequirements", "gameLoop", "controls", "entities", "uiLayout", "assets", "gameplayRules"]
};

// --- SCHEMA 2: TECHNICAL ARCHITECTURE ---
const architectureSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    recommendedEngine: { type: Type.STRING, description: "The best web engine for this task." },
    language: { type: Type.STRING, description: "JavaScript or TypeScript." },
    architecture: {
      type: Type.OBJECT,
      properties: {
        style: { type: Type.STRING, description: "Pattern name (ECS, Component, etc)." },
        description: { type: Type.STRING, description: "Brief technical summary." },
        reasoning: {
          type: Type.OBJECT,
          properties: {
            chosen: { type: Type.STRING, description: "Name of the chosen architecture" },
            because: { type: Type.ARRAY, items: { type: Type.STRING }, description: "List of reasons why this fits." },
            rejected: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  model: { type: Type.STRING },
                  reason: { type: Type.STRING }
                },
                required: ["model", "reason"]
              },
              description: "List of rejected alternatives and why."
            }
          },
          required: ["chosen", "because", "rejected"]
        },
        nodes: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              description: { type: Type.STRING },
              type: { type: Type.STRING, enum: ['pattern', 'component', 'system', 'data'] }
            },
            required: ["name", "type", "description"]
          }
        }
      },
      required: ["style", "description", "reasoning", "nodes"]
    },
    techStack: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          category: { type: Type.STRING },
          name: { type: Type.STRING },
          description: { type: Type.STRING }
        },
        required: ["category", "name", "description"]
      }
    },
    prerequisites: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          item: { type: Type.STRING },
          command: { type: Type.STRING },
          importance: { type: Type.STRING, enum: ['Critical', 'Recommended', 'Optional'] }
        },
        required: ["item", "importance"]
      }
    }
  },
  required: ["recommendedEngine", "language", "architecture", "techStack", "prerequisites"]
};

export const generateBlueprint = async (
  prefs: UserPreferences,
  onStatus?: (status: string) => void
): Promise<GeneratedGame> => {
  const ai = getAIClient();

  // STEP 1: QUANTIZE REQUIREMENTS (with retry)
  if (onStatus) onStatus("Analyzing game concept...");

  const specData = await retryWithBackoff(async () => {
    if (onStatus) onStatus("Quantizing requirements...");

    const response = await ai.generateContent({
      contents: PromptRegistry.QuantizeRequirements(prefs),
      config: {
        responseMimeType: "application/json",
        responseSchema: specSchema,
        thinkingConfig: { thinkingBudget: 2048 },
        maxOutputTokens: 8192
      }
    });

    const data = parseAndSanitize(response.text || "{}");
    validateStructure(data, ["title", "summary", "coreMechanics", "visualRequirements", "gameLoop", "controls", "entities", "uiLayout", "tensionCurve", "assets", "gameplayRules"], "Blueprint Spec");
    return data;
  }, 3, "Blueprint Spec");

  // STEP 2: GENERATE ARCHITECTURE (with retry)
  if (onStatus) onStatus("Designing system architecture...");

  const archData = await retryWithBackoff(async () => {
    if (onStatus) onStatus("Architecting systems...");

    const response = await ai.generateContent({
      contents: PromptRegistry.ArchitectSystem(specData, prefs),
      config: {
        responseMimeType: "application/json",
        responseSchema: architectureSchema,
        thinkingConfig: { thinkingBudget: 2048 },
        maxOutputTokens: 8192
      }
    });

    const data = parseAndSanitize(response.text || "{}");
    validateStructure(data, ["architecture", "techStack"], "Blueprint Architecture");
    return data;
  }, 3, "Blueprint Architecture");

  if (onStatus) onStatus("Blueprint complete!");

  return { ...specData, ...archData };
};

export const refineBlueprint = async (
  currentBlueprint: GeneratedGame,
  critique: string,
  onStatus?: (status: string) => void
): Promise<GeneratedGame> => {
  const ai = getAIClient();
  
  if (onStatus) onStatus("Analyzing refinement request...");

  // We'll combine the schemas into one for the refinement step
  const combinedSchema: Schema = {
    type: Type.OBJECT,
    properties: {
      ...specSchema.properties,
      ...architectureSchema.properties
    },
    // No required fields for refinement - allow partial updates
    required: []
  };

  const refineData = await retryWithBackoff(async () => {
    if (onStatus) onStatus("Applying design changes...");
    
    const response = await ai.generateContent({
      contents: PromptRegistry.RefineBlueprint(currentBlueprint, critique),
      config: {
        responseMimeType: "application/json",
        responseSchema: combinedSchema,
        thinkingConfig: { thinkingBudget: 4096 },
        maxOutputTokens: 8192
      }
    });

    const data = parseAndSanitize(response.text || "{}");
    
    // Validate we got something back
    if (Object.keys(data).length === 0) {
      throw new Error("AI returned empty refinement. The model may have failed to generate changes.");
    }
    
    return data;
  }, 3, "Blueprint Refinement");

  if (onStatus) onStatus("Merging changes...");

  // Merge with existing to preserve any fields not returned
  const merged = {
    ...currentBlueprint,
    ...refineData
  };
  
  if (onStatus) onStatus("Refinement complete!");
  
  return merged;
};
