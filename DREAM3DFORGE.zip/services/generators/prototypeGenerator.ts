import { Type, Schema } from "../googleSchemaShim";
import { UserPreferences, GeneratedGame, GameAudio, ForgeManifest } from "../../types";
import { getAIClient } from "../client";
import { parseAndSanitize, validateStructure, retryWithBackoff, extractHTMLFromResponse } from "../utils/aiHelpers";
import { generateShortHash } from "../../utils/tokenEstimator";
import { PromptRegistry } from "../promptRegistry";
import { ENGINE_VERSION } from "../../version";
import { TOUCH_CONTROLS_INJECTION } from "../templates/touchControls";
import { buildEnhancedPrototypePrompt } from "../templates/enhancedPrompt";

const prototypeSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    html: {
      type: Type.STRING,
      description: "Complete, self-contained HTML with embedded JS/CSS. Must be a playable game."
    },
    instructions: {
      type: Type.STRING,
      description: "Clear control instructions (WASD, mouse, etc)."
    }
  },
  required: ["html", "instructions"]
};

// GPU constraint rules by tier
const GPU_RULES: Record<string, string> = {
  'low': `
GPU TIER: LOW (Mobile/iGPU)
- MAX 50 draw calls
- MAX 500 total triangles
- NO dynamic shadows
- NO post-processing
- Use vertex colors instead of textures
- Target 30+ FPS
`,
  'mid': `
GPU TIER: MID (Laptop/Standard)
- MAX 200 draw calls
- MAX 10,000 triangles
- ONE shadow-casting light maximum
- Basic post-processing OK (bloom only)
- Simple textures OK
- Target 60 FPS
`,
  'high': `
GPU TIER: HIGH (Desktop/Discrete)
- Dynamic shadows allowed
- Post-processing allowed (bloom, AO, etc)
- Higher poly models OK
- Multiple light sources OK
- Target 60+ FPS
`
};

/**
 * Inject touch controls into generated HTML
 */
function injectTouchControls(html: string): string {
  // Insert touch controls before </body>
  if (html.includes('</body>')) {
    return html.replace('</body>', TOUCH_CONTROLS_INJECTION + '\n</body>');
  }
  // Fallback: append at end
  return html + '\n' + TOUCH_CONTROLS_INJECTION;
}

export const generatePrototype = async (
  blueprint: GeneratedGame,
  prefs: UserPreferences,
  audio: GameAudio | undefined,
  onStatus?: (status: string) => void
): Promise<GeneratedGame> => {
  const ai = getAIClient();

  // Build audio context string
  let audioContextStr = "NO CUSTOM AUDIO - Skip audio integration.";
  if (audio?.soundEffects?.length) {
    audioContextStr = `
PROCEDURAL AUDIO (integrate these functions):

// Background Music
${audio.backgroundMusic}

// Sound Effects
${audio.soundEffects.map(sfx => `
// ${sfx.name} - Trigger: ${sfx.trigger}
${sfx.code}
`).join('\n')}

INTEGRATION INSTRUCTIONS (MANDATORY):
1. COPY & PASTE the above audio functions directly into your <script>.
2. CALL playMusic(audioCtx) inside your "Start Game" click handler (after audioCtx.resume()).
3. CALL the SFX functions (e.g. playJump(audioCtx)) at the moment the action happens.
`;
  }

  const gpuRules = GPU_RULES[prefs.capabilities.gpuTier] || GPU_RULES['mid'];

  if (onStatus) onStatus("Generating game code...");

  // Generate with retry logic
  const prototypeData = await retryWithBackoff(async () => {
    if (onStatus) onStatus("Synthesizing prototype...");

    // Use the enhanced skeleton-based prompt for better quality
    const enhancedPrompt = buildEnhancedPrototypePrompt(blueprint, prefs, audioContextStr, gpuRules);

    const response = await ai.generateContent({
      
      contents: enhancedPrompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: prototypeSchema,
        thinkingConfig: { thinkingBudget: 12000 }, // More thinking for skeleton customization
        maxOutputTokens: 24000 // Higher for full game code
      }
    });

    // Try to parse, with fallback for common issues
    let data;
    try {
      data = parseAndSanitize(response.text || "{}");
    } catch (parseError) {
      console.warn("[Prototype] JSON parse failed, attempting direct HTML extraction...", parseError.message);
      const extractedHtml = extractHTMLFromResponse(response.text || "");
      if (extractedHtml && extractedHtml.length > 500) {
        data = {
          html: extractedHtml,
          instructions: "Instructions extracted from partial response. Check game for controls."
        };
      } else {
        // Detect refusal
        const text = (response.text || "").trim().toLowerCase();
        if (text.startsWith("i apologize") || text.startsWith("i cannot") || text.startsWith("i'm sorry")) {
          throw new Error("AI Refusal: The model declined to generate the game code. Try changing the prompt or seed.");
        }
        throw parseError;
      }
    }

    // Relaxed validation - only require html field, instructions can be generated
    validateStructure(data, ["html"], "Prototype");
    
    // Auto-generate instructions if missing
    if (!data.instructions) {
      console.warn("[Prototype] Missing instructions, generating default...");
      data.instructions = `Controls: ${blueprint.controls?.scheme || 'Keyboard'} - ${blueprint.controls?.mappings?.map((m: any) => `${m.input}: ${m.action}`).join(', ') || 'Arrow keys to move, Space to action'}`;
    }

    // Basic validation of HTML content
    const html = data.html || "";
    const hasScript = /<script/i.test(html);
    const engine = prefs.gameEngine.toLowerCase();

    // Check for engine-specific keywords (warning only, not blocking)
    let hasEngine = true;
    if (engine.includes('three')) {
      hasEngine = /three|THREE|WebGLRenderer|Scene|PerspectiveCamera/i.test(html);
    } else if (engine.includes('babylon')) {
      hasEngine = /BABYLON|Engine|Scene/i.test(html);
    } else if (engine.includes('p5')) {
      hasEngine = /p5|createCanvas|setup|draw/i.test(html);
    } else if (engine.includes('kaboom')) {
      hasEngine = /kaboom|kaplay/i.test(html);
    }

    // Enhanced validation - check for critical game systems
    const hasGameLoop = /requestAnimationFrame|setInterval.*update|gameLoop|animate\(\)|requestAnimationFrame/i.test(html);
    const hasInputHandling = /keydown|keyup|addEventListener.*key|Input\.keys|getPlayerInput|keyPressed/i.test(html);
    const hasDeathSystem = /die\(|gameOver|death|restart|isRunning\s*=\s*false|reset\(\)/i.test(html);
    const hasTelemetry = /forge-telemetry|postMessage/i.test(html);
    const hasState = /State\s*=|GameState|isRunning|gameState/i.test(html);

    if (!hasScript) {
      console.error("Critical: Generated HTML missing script tag. Length:", html.length);
      throw new Error(`[v2.5.2] Code Incomplete: Missing <script> block. Output length: ${html.length}`);
    }

    // Engine check is now a warning, not a hard fail - Trinity model might use different patterns
    if (!hasEngine) {
      console.warn(`[Prototype] Engine keyword check failed for ${prefs.gameEngine}, but code may still be valid.`);
      // Don't throw - some models generate working code without obvious library references
    }

    if (html.length < 1500) {
      throw new Error("Generated code is too short (possible truncation). Expected 1500+ chars.");
    }

    if (!hasGameLoop) {
      console.warn("Warning: No game loop detected. Game may not animate.");
    }

    if (!hasInputHandling) {
      console.warn("Warning: No input handling detected. Game may not be controllable.");
    }

    if (!hasDeathSystem) {
      console.warn("Warning: No death/restart system detected. Game may not have proper game over.");
    }

    // Log validation results for debugging
    console.log("[Prototype Validation]", {
      length: html.length,
      hasEngine,
      hasGameLoop,
      hasInputHandling,
      hasDeathSystem,
      hasTelemetry,
      hasState
    });

    return data;
  }, 3, "Prototype");

  // INJECT TOUCH CONTROLS
  if (onStatus) onStatus("Adding mobile touch controls...");
  const htmlWithTouch = injectTouchControls(prototypeData.html);

  // Update instructions to mention touch
  const touchInstructions = prototypeData.instructions +
    '\n\n📱 MOBILE: Virtual joystick (left) + action buttons (right)';

  // Generate manifest
  const specHash = generateShortHash(JSON.stringify(blueprint));
  const buildHash = generateShortHash(htmlWithTouch);

  const manifest: ForgeManifest = {
    version: ENGINE_VERSION,
    timestamp: Date.now(),
    seed: prefs.seed,
    specHash,
    buildHash,
    platform: prefs.platform,
    quality: prefs.quality
  };

  if (onStatus) onStatus("Prototype complete!");

  return {
    ...blueprint,
    html: htmlWithTouch,
    instructions: touchInstructions,
    audio,
    manifest
  };
};
