import { Type, Schema } from "../googleSchemaShim";
import { GeneratedGame, RefinementSettings } from "../../types";
import { getAIClient } from "../client";
import { parseAndSanitize, validateStructure, compressCodeForContext, retryWithBackoff, extractHTMLFromResponse } from "../utils/aiHelpers";
import { PromptRegistry } from "../promptRegistry";

// Simplified schema - just get the full code, patches are error-prone
const refinementSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    html: {
      type: Type.STRING,
      description: "The complete, modified HTML file with all changes applied."
    },
    instructions: {
      type: Type.STRING,
      description: "Updated gameplay instructions if controls changed."
    },
    changelog: {
      type: Type.STRING,
      description: "Brief description of what was changed."
    }
  },
  required: ["html"]
};

export const refineGame = async (
  currentGame: GeneratedGame,
  instruction: string,
  settings?: RefinementSettings
): Promise<GeneratedGame> => {
  const ai = getAIClient();

  // Pass full context - compression was causing "too short" errors by confusing the model
  const contextCode = currentGame.html || "";

  const result = await retryWithBackoff(async () => {
    const response = await ai.generateContent({
      
      contents: PromptRegistry.RefineCode(instruction, contextCode),
      config: {
        responseMimeType: "application/json",
        responseSchema: refinementSchema,
        thinkingConfig: { thinkingBudget: 8000 },
        maxOutputTokens: settings?.maxOutputTokens ?? 24000,
        temperature: settings?.temperature ?? 0.7,
        topP: settings?.topP ?? 0.95,
        topK: settings?.topK ?? 40
      }
    });

    // Try to parse, with HTML extraction fallback
    let data;
    try {
      data = parseAndSanitize(response.text || "{}");
    } catch (parseError) {
      const extractedHtml = extractHTMLFromResponse(response.text || "");
      if (extractedHtml) {
        data = { html: extractedHtml, instructions: currentGame.instructions };
      } else {
        throw parseError;
      }
    }

    validateStructure(data, ["html"], "Refinement");

    // Enhanced validation - make sure we didn't break the game
    const html = data.html;

    if (html.length < 500) {
      throw new Error("Refined code seems too short - may be incomplete");
    }

    // Check that critical systems weren't removed
    const hasScript = /<script/i.test(html);
    const hasGameLoop = /requestAnimationFrame|gameLoop|animate\(\)/i.test(html);
    const hasEngine = /THREE|BABYLON|p5|kaboom/i.test(html);

    if (!hasScript) {
      throw new Error("Refinement broke the game - missing <script> tag");
    }

    if (!hasGameLoop) {
      console.warn("Warning: Game loop may have been removed during refinement");
    }

    if (!hasEngine && currentGame.html && /THREE|BABYLON|p5|kaboom/i.test(currentGame.html)) {
      throw new Error("Refinement removed the game engine - rejected");
    }

    // If the refined code is significantly shorter than original, that's suspicious
    // if (currentGame.html && html.length < currentGame.html.length * 0.5) {
    //   console.warn("Warning: Refined code is much shorter than original - may have lost content");
    // }

    return data;
  }, 2, "Refinement");

  console.log("Refinement applied:", result.changelog || "Changes applied");

  return {
    ...currentGame,
    html: result.html,
    instructions: result.instructions || currentGame.instructions
  };
};
