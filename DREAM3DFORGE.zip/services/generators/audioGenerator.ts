/**
 * Generates audio/soundscapes for the game.
 * Uses Web Audio API code synthesis via AI generation.
 */

import { Type, Schema } from "../googleSchemaShim";
import { PromptRegistry } from "../promptRegistry";
import { getAIClient } from "../client";
import type { GeneratedGame, UserPreferences } from "../../types";
import { parseAndSanitize, retryWithBackoff } from "../utils/aiHelpers";

// --- Audio Types ---
export interface AudioResult {
  description: string;
  backgroundMusic: string;
  soundEffects: Array<{
    name: string;
    trigger: string;
    code: string;
  }>;
}

// --- Audio Schema for Gemini ---
const audioSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    description: { 
      type: Type.STRING, 
      description: "Description of the audio style and mood" 
    },
    backgroundMusic: { 
      type: Type.STRING, 
      description: "JavaScript function code for background music using Web Audio API" 
    },
    soundEffects: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          trigger: { type: Type.STRING },
          code: { type: Type.STRING }
        },
        required: ["name", "trigger", "code"]
      }
    }
  },
  required: ["description", "backgroundMusic", "soundEffects"]
};

// Legacy monolithic function - kept for backwards compatibility
export const generateSoundscape = async (
  blueprint: GeneratedGame,
  prefs: UserPreferences,
  onStatus?: (msg: string) => void
): Promise<AudioResult> => {
  const ai = getAIClient();
  if (onStatus) onStatus("Composing audio...");

  const data = await retryWithBackoff(async () => {
    const response = await ai.generateContent({
      contents: PromptRegistry.DesignSoundscape(blueprint, prefs),
      config: {
        responseMimeType: "application/json",
        responseSchema: audioSchema,
        maxOutputTokens: 8192
      }
    });
    return parseAndSanitize(response.text) as AudioResult;
  }, 2, "Audio Generation");

  if (onStatus) onStatus("Audio composed!");
  return data;
};

/**
 * NEW: Optimized BGM-only generation (lower token usage)
 * Returns just the background music code string
 */
export const generateBGM = async (
  blueprint: GeneratedGame,
  prefs: UserPreferences,
  onStatus?: (msg: string) => void
): Promise<{ description: string; backgroundMusic: string }> => {
  const ai = getAIClient();
  if (onStatus) onStatus("Composing background music...");

  const data = await retryWithBackoff(async () => {
    const response = await ai.generateContent({
      contents: PromptRegistry.DesignBGM(blueprint, prefs),
      config: {
        responseMimeType: "application/json",
        maxOutputTokens: 4096
      }
    });
    return parseAndSanitize(response.text) as { description: string; backgroundMusic: string };
  }, 2, "BGM Generation");

  if (onStatus) onStatus("Background music ready!");
  return data;
};

/**
 * NEW: Optimized single SFX generation (very low token usage)
 * Returns one sound effect at a time
 */
export const generateSFX = async (
  blueprint: GeneratedGame,
  prefs: UserPreferences,
  sfxName: string,
  trigger: string,
  onStatus?: (msg: string) => void
): Promise<{ name: string; trigger: string; code: string }> => {
  const ai = getAIClient();
  if (onStatus) onStatus(`Creating ${sfxName} sound effect...`);

  const data = await retryWithBackoff(async () => {
    const response = await ai.generateContent({
      contents: PromptRegistry.DesignSFX(blueprint, prefs, sfxName, trigger),
      config: {
        responseMimeType: "application/json",
        maxOutputTokens: 2048
      }
    });
    return parseAndSanitize(response.text) as { name: string; trigger: string; code: string };
  }, 2, `SFX: ${sfxName}`);

  return data;
};

/**
 * NEW: Parallel SFX generation for multiple sound effects
 * More efficient than sequential calls but still token-cheap per effect
 */
export const generateMultipleSFX = async (
  blueprint: GeneratedGame,
  prefs: UserPreferences,
  sfxList: Array<{ name: string; trigger: string }>,
  onStatus?: (msg: string) => void
): Promise<Array<{ name: string; trigger: string; code: string }>> => {
  if (onStatus) onStatus(`Creating ${sfxList.length} sound effects in parallel...`);
  
  const promises = sfxList.map(({ name, trigger }) => 
    generateSFX(blueprint, prefs, name, trigger, onStatus)
  );
  
  return Promise.all(promises);
};

/**
 * NEW: Complete optimized soundscape generation
 * Uses separate BGM + parallel SFX calls for better token efficiency
 */
export const generateOptimizedSoundscape = async (
  blueprint: GeneratedGame,
  prefs: UserPreferences,
  onStatus?: (msg: string) => void
): Promise<AudioResult> => {
  // Generate BGM first
  const bgmData = await generateBGM(blueprint, prefs, onStatus);
  
  // Define common SFX for the genre (could be customized per genre)
  const commonSFX = [
    { name: "StartGame", trigger: "Game Start" },
    { name: "Success", trigger: "Objective Complete" },
    { name: "Fail", trigger: "Player Failure" },
    { name: "Click", trigger: "UI Click" }
  ];
  
  // Add game-specific SFX based on mechanics
  const mechanics = (blueprint as any).coreMechanics || [];
  if (mechanics.includes("jumping") || prefs.genre?.toLowerCase().includes("platform")) {
    commonSFX.push({ name: "Jump", trigger: "Spacebar / Jump" });
  }
  if (mechanics.includes("shooting") || prefs.genre?.toLowerCase().includes("shoot") || prefs.genre?.toLowerCase().includes("action")) {
    commonSFX.push({ name: "Shoot", trigger: "Fire Button" }, { name: "Explosion", trigger: "Enemy Destroyed" });
  }
  if (mechanics.includes("collecting") || prefs.genre?.toLowerCase().includes("puzzle")) {
    commonSFX.push({ name: "Collect", trigger: "Item Collected" });
  }

  // Generate all SFX in parallel
  const soundEffects = await generateMultipleSFX(blueprint, prefs, commonSFX, onStatus);

  if (onStatus) onStatus("Audio composed!");
  
  return {
    description: bgmData.description,
    backgroundMusic: bgmData.backgroundMusic,
    soundEffects
  };
};
