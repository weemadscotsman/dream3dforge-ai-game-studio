/**
 * Storage Service - IndexedDB persistence for Dream3DForge
 * Saves projects, settings, and history locally
 */

import { GeneratedGame, UserPreferences } from "../types";

const DB_NAME = "Dream3DForge";
const DB_VERSION = 1;

interface StoredProject {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  preferences: UserPreferences;
  game: GeneratedGame | null;
  specFrozen: boolean;
  seedLocked: boolean;
}

interface StoredSettings {
  id: string;
  lastPreferences: Partial<UserPreferences>;
  theme: 'dark' | 'light';
  telemetryEnabled: boolean;
}

let db: IDBDatabase | null = null;

/**
 * Initialize the database
 */
export async function initDB(): Promise<IDBDatabase> {
  if (db) return db;

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onerror = () => reject(request.error);
    
    request.onsuccess = () => {
      db = request.result;
      resolve(db);
    };

    request.onupgradeneeded = (event) => {
      const database = (event.target as IDBOpenDBRequest).result;

      // Projects store
      if (!database.objectStoreNames.contains("projects")) {
        const projectStore = database.createObjectStore("projects", { keyPath: "id" });
        projectStore.createIndex("name", "name", { unique: false });
        projectStore.createIndex("updatedAt", "updatedAt", { unique: false });
      }

      // Settings store
      if (!database.objectStoreNames.contains("settings")) {
        database.createObjectStore("settings", { keyPath: "id" });
      }

      // History store (for undo/redo)
      if (!database.objectStoreNames.contains("history")) {
        const historyStore = database.createObjectStore("history", { keyPath: "id" });
        historyStore.createIndex("projectId", "projectId", { unique: false });
        historyStore.createIndex("timestamp", "timestamp", { unique: false });
      }
    };
  });
}

/**
 * Save a project
 */
export async function saveProject(project: StoredProject): Promise<void> {
  const database = await initDB();
  
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(["projects"], "readwrite");
    const store = transaction.objectStore("projects");
    
    project.updatedAt = Date.now();
    const request = store.put(project);
    
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

/**
 * Load a project by ID
 */
export async function loadProject(id: string): Promise<StoredProject | null> {
  const database = await initDB();
  
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(["projects"], "readonly");
    const store = transaction.objectStore("projects");
    const request = store.get(id);
    
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error);
  });
}

/**
 * List all projects
 */
export async function listProjects(): Promise<StoredProject[]> {
  const database = await initDB();
  
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(["projects"], "readonly");
    const store = transaction.objectStore("projects");
    const index = store.index("updatedAt");
    const request = index.getAll();
    
    request.onsuccess = () => {
      // Sort by updatedAt descending (most recent first)
      const projects = request.result.sort((a, b) => b.updatedAt - a.updatedAt);
      resolve(projects);
    };
    request.onerror = () => reject(request.error);
  });
}

/**
 * Delete a project
 */
export async function deleteProject(id: string): Promise<void> {
  const database = await initDB();
  
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(["projects"], "readwrite");
    const store = transaction.objectStore("projects");
    const request = store.delete(id);
    
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

/**
 * Save settings
 */
export async function saveSettings(settings: StoredSettings): Promise<void> {
  const database = await initDB();
  
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(["settings"], "readwrite");
    const store = transaction.objectStore("settings");
    const request = store.put(settings);
    
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });
}

/**
 * Load settings
 */
export async function loadSettings(): Promise<StoredSettings | null> {
  const database = await initDB();
  
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(["settings"], "readonly");
    const store = transaction.objectStore("settings");
    const request = store.get("default");
    
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error);
  });
}

/**
 * Generate a unique project ID
 */
export function generateProjectId(): string {
  return `proj_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Create a new project object
 */
export function createProject(name: string, preferences: UserPreferences): StoredProject {
  const now = Date.now();
  return {
    id: generateProjectId(),
    name,
    createdAt: now,
    updatedAt: now,
    preferences,
    game: null,
    specFrozen: false,
    seedLocked: false
  };
}

export type { StoredProject, StoredSettings };
