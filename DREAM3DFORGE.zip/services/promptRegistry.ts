import { UserPreferences, GeneratedGame, GameEngine } from "../types";
import { deriveDifficultySignature } from "./difficultyMath";
import { ASSET_HELPERS } from "./templates/assetHelpers";
import { AUDIO_HELPERS } from "./templates/audioHelpers";

/**
 * PROMPT REGISTRY v2.1 - DOCTRINE ENFORCED
 * 
 * DREAM3DFORGE IDENTITY:
 * "Arcade-scale, session-based, skill-first games designed for 5-20 minute loops."
 * 
 * THE 5 LAWS:
 * 1. Single-Session Completeness - Understand in 30s, fail in 1-3min, peak in 20min
 * 2. One Mechanic, Deepened - One primary verb, mastery through repetition
 * 3. Failure Is Teacher - No XP bars, death = restart, clear cause
 * 4. Variance Not Content - Seeds, modifiers, mixes. Not levels/maps/art
 * 5. Tension Curve - Calm → Pressure → Panic → Resolution
 */

// ============================================================================
// DOCTRINE ENFORCEMENT
// ============================================================================

const DOCTRINE = {
  identity: "Arcade-scale, session-based, skill-first games designed for 5-20 minute loops",

  laws: {
    singleSession: "Player understands goal in 30 seconds, fails within 1-3 minutes, reaches peak within 20 minutes. No tutorials, no lore dumps, no complex menus.",
    oneMechanic: "One primary verb (move+shoot, dodge, trade-off, pattern-read, risk-vs-greed). If multiple primary mechanics detected, simplify.",
    failureTeacher: "Progress = player skill, not XP bars or unlock trees. Death is instant restart with clear cause.",
    varianceNotContent: "Replayability via seeds, enemy mixes, modifiers, environmental shifts. NOT new levels, maps, or art.",
    tensionCurve: "Every run follows: Calm → Pressure → Panic → Relief/Death. Inject escalation spikes."
  },

  whitelistGenres: [
    "Arena Shooter",
    "Dodge Survival",
    "Bullet Hell",
    "Tactical Grid",
    "Rhythm Reaction",
    "One-Screen Platformer",
    "Turnless Roguelike",
    "Resource Panic",
    "Wave Defense",
    "Time Attack",
    "Score Chase"
  ],

  blacklistConcepts: [
    "open world",
    "story-driven",
    "narrative",
    "mmo",
    "multiplayer lobby",
    "crafting system",
    "base building",
    "simulation",
    "management",
    "level editor",
    "user generated content",
    "save system",
    "progression tree",
    "skill tree",
    "inventory management",
    "quest system",
    "dialogue trees",
    "cutscenes"
  ]
};

/**
 * Check if a concept violates doctrine
 */
export function checkDoctrineViolation(concept: string): { valid: boolean; reason?: string; suggestion?: string } {
  const lowerConcept = concept.toLowerCase();

  for (const blacklisted of DOCTRINE.blacklistConcepts) {
    if (lowerConcept.includes(blacklisted)) {
      return {
        valid: false,
        reason: `"${blacklisted}" exceeds instant-play doctrine. Dream3DForge specializes in short-session, high-intensity games (5-20 minute loops).`,
        suggestion: getSuggestionForBlacklisted(blacklisted)
      };
    }
  }

  return { valid: true };
}

function getSuggestionForBlacklisted(term: string): string {
  const suggestions: Record<string, string> = {
    "open world": "Try: Arena survival with expanding danger zones",
    "story-driven": "Try: Environmental storytelling through gameplay (like Dark Souls)",
    "narrative": "Try: Emergent narrative through run variance",
    "crafting system": "Try: Quick power-up selection between waves",
    "base building": "Try: Tower defense with instant placement",
    "simulation": "Try: Time-pressure resource management",
    "management": "Try: Real-time triage under escalating threat",
    "inventory management": "Try: Limited loadout selection pre-run",
    "progression tree": "Try: Per-run upgrade choices that reset on death",
    "skill tree": "Try: Mutually exclusive power picks each run"
  };
  return suggestions[term] || "Try: Simpler scope with one core mechanic";
}

// ============================================================================
// ENGINE SPECIFICATIONS - Enhanced with complete boilerplate
// ============================================================================

const ENGINE_SPECS: Record<string, string> = {
  [GameEngine.ThreeJS]: `
ENGINE: Three.js (Standard WebGL)

REQUIRED IMPORTS (use exact versions):
import * as THREE from 'https://unpkg.com/three@0.160.0/build/three.module.js';
import { PointerLockControls } from 'https://unpkg.com/three@0.160.0/examples/jsm/controls/PointerLockControls.js';
import { OrbitControls } from 'https://unpkg.com/three@0.160.0/examples/jsm/controls/OrbitControls.js';

MANDATORY STRUCTURE:
- Scene with background color and optional fog
- PerspectiveCamera with proper aspect ratio
- WebGLRenderer with antialiasing, shadows, pixel ratio capped at 2
- Resize handler that updates camera and renderer
- Clock-based delta time in animation loop
`,
  [GameEngine.ThreeJS_WebGPU]: `
ENGINE: Three.js WebGPU (Experimental)
Import from: https://unpkg.com/three@0.167.0/build/three.webgpu.js
Must use async init() pattern with await renderer.init()
`,
  [GameEngine.P5JS]: `
ENGINE: p5.js
Include via CDN: https://cdnjs.cloudflare.com/ajax/libs/p5.js/1.9.0/p5.js
Use setup(), draw(), windowResized() pattern
Use WEBGL mode for 3D: createCanvas(windowWidth, windowHeight, WEBGL)
`,
  [GameEngine.BabylonJS]: `
ENGINE: Babylon.js
Include via CDN: https://cdn.babylonjs.com/babylon.js
Create canvas element with id="renderCanvas"
Use engine.runRenderLoop() for animation
`,
  [GameEngine.KaboomJS]: `
ENGINE: Kaboom.js
Import from: https://unpkg.com/kaboom@3000.0.1/dist/kaboom.mjs
Initialize with kaboom({ background, width, height })
Use scenes and go() for state management
`,
  [GameEngine.RawWebGL]: `
ENGINE: Raw WebGL
Get context: canvas.getContext('webgl2') || canvas.getContext('webgl')
Write vertex and fragment shaders as string literals
Handle all buffer management manually
`
};

// ============================================================================
// GENRE MECHANICS (DOCTRINE-COMPLIANT)
// ============================================================================

const GENRE_MECHANICS: Record<string, string> = {
  'Arena Shooter': `
DOCTRINE: Survive waves, get stronger, die eventually, beat your record.

CORE LOOP (One Mechanic):
- PRIMARY VERB: Shoot + Position
- Move to avoid, shoot to survive, collect to upgrade

SESSION STRUCTURE (20 min max):
- Wave 1-3: Learn controls, easy enemies (CALM)
- Wave 4-7: Enemy variety, resource pressure (PRESSURE)  
- Wave 8-12: Screen chaos, split-second decisions (PANIC)
- Death: Show score, time, wave reached. Instant restart.

TENSION INJECTION:
- Enemy spawn rate increases every 30 seconds
- Arena shrinks or hazards appear at wave 5+
- Audio tempo increases with wave count
- Screen shake scales with danger level

VARIANCE (Not Content):
- Enemy type weights randomized per seed
- Power-up order shuffled
- Spawn positions varied
- Boss patterns have variants

REQUIRED ELEMENTS:
- Player: WASD move, mouse aim, click shoot
- Enemies: At least 3 types with distinct behaviors
- Upgrades: Weapon damage, fire rate, move speed (pick between waves)
- HUD: Health, wave count, score, high score
- Death: Freeze frame, score display, "Click to restart"
`,

  'Dodge Survival': `
DOCTRINE: Don't get hit. Last as long as possible. Pure skill expression.

CORE LOOP (One Mechanic):
- PRIMARY VERB: Dodge
- Everything kills in one hit. You move. That's it.

SESSION STRUCTURE (10 min max):
- 0-30s: Slow projectiles, learn patterns (CALM)
- 30s-2min: Speed increase, pattern complexity (PRESSURE)
- 2min+: Chaos, overlapping patterns (PANIC)
- Death: Instant. Show time survived. Restart in 1 click.

TENSION INJECTION:
- Projectile speed increases linearly with time
- New projectile types introduced at intervals
- Safe zones shrink
- Background music BPM increases

VARIANCE:
- Pattern sequences randomized from pool
- Color schemes shift per run
- Projectile spawn angles seeded

REQUIRED ELEMENTS:
- Player: Small hitbox, responsive movement (WASD or arrows)
- Projectiles: Clear visual language (color = behavior)
- Timer: Prominent survival time display
- Near-miss feedback: Visual/audio reward for close dodges
- Death: Screen flash, time display, instant restart option
`,

  'Bullet Hell': `
DOCTRINE: Read patterns, find safe pixels, flow state through chaos.

CORE LOOP (One Mechanic):
- PRIMARY VERB: Navigate (precision movement through bullet fields)
- Optional: Shoot back (but dodging is primary)

SESSION STRUCTURE (15 min max):
- Phase 1: Single pattern types (CALM)
- Phase 2: Overlapping patterns (PRESSURE)
- Phase 3: Boss patterns with tells (PANIC)
- Clear or death: Score screen, restart

TENSION INJECTION:
- Bullet density doubles every phase
- Screen increasingly filled
- Boss health bars create urgency
- Graze system rewards risk

VARIANCE:
- Pattern library shuffled per run
- Boss attack order randomized
- Bullet colors/speeds varied by seed

REQUIRED ELEMENTS:
- Tiny player hitbox (visible dot)
- Bullet patterns with clear visual hierarchy
- Graze counter (near-miss scoring)
- Bomb/clear option (limited, emergency use)
- Boss with health bar and pattern phases
`,

  'Tactical Grid': `
DOCTRINE: Chess-like decisions, every move matters, elegant death spirals.

CORE LOOP (One Mechanic):
- PRIMARY VERB: Position (move unit, consequences unfold)
- Turn-based but snappy (no long animations)

SESSION STRUCTURE (20 min max):
- Turns 1-5: Setup, understand enemy intents (CALM)
- Turns 6-15: Resource depletion, hard choices (PRESSURE)
- Turns 16+: Survival mode, calculated sacrifices (PANIC)
- Win/Lose: Clear end state, score breakdown, restart

TENSION INJECTION:
- Enemy count increases each turn
- Special enemies with delayed but devastating attacks
- Terrain hazards activate over time
- Resources don't regenerate

VARIANCE:
- Enemy spawn positions seeded
- Unit ability pools randomized
- Map hazard placement varied
- Objective locations shuffled

REQUIRED ELEMENTS:
- Grid-based movement (click to move)
- Enemy intent display (show what they'll do next turn)
- Limited actions per turn (2-3 moves)
- Clear win/lose conditions
- Undo last move option (limited uses)
`,

  'Rhythm Reaction': `
DOCTRINE: Feel the beat, hit the mark, enter flow state.

CORE LOOP (One Mechanic):
- PRIMARY VERB: Time (press input at correct moment)
- Music and gameplay are inseparable

SESSION STRUCTURE (3-5 min per song/level):
- Intro: Establish beat, easy hits (CALM)
- Verse: Pattern complexity increases (PRESSURE)
- Chorus: Maximum density, flow or fail (PANIC)
- End: Resolution, score display

TENSION INJECTION:
- Note density increases toward chorus
- Multiplier system rewards streaks
- Miss = broken combo = pressure
- Visual effects intensify with performance

VARIANCE:
- Note patterns generated from audio analysis
- Speed modifiers between runs
- Visual themes randomized

REQUIRED ELEMENTS:
- Clear hit zones with timing feedback
- Combo counter prominently displayed
- Accuracy percentage
- Grade system (S/A/B/C/F)
- Input: Keys, touch, or mouse timing
`,

  'One-Screen Platformer': `
DOCTRINE: Mario-style 8-bit platformer with procedural levels and tight controls.

CORE LOOP (Primary Mechanic):
- PRIMARY VERB: Jump (run, jump, stomp enemies, collect coins)
- Secondary: Stomp (jump on enemies to defeat them)
- Classic side-scrolling platformer mechanics

SESSION STRUCTURE (5-15 min per world):
- World 1: Learn controls, few enemies, generous platforms (CALM)
- World 2-3: Gaps, moving platforms, more enemies (PRESSURE)
- World 4+: Precise jumps, enemy combinations, time pressure (PANIC)
- Death: Lose a life, restart from checkpoint or level start

PHYSICS REQUIREMENTS (CRITICAL):
- Gravity: 0.5 units/frame acceleration
- Jump: Variable height (hold button = higher jump)
- Coyote Time: 6 frames after leaving platform
- Max Fall Speed: Capped to prevent tunneling
- Friction: 0.85 for ground, 0.95 for air

ENEMY TYPES:
1. Goomba: Walks left/right, dies to stomp, kills player on touch
2. Koopa: Walks, becomes shell when stomped, shell kills other enemies
3. Piranha Plant: Static, emerges from pipes, cannot be stomped
4. Flying Enemy: Moves in sine wave pattern

COLLECTIBLES:
- Coins: +100 points, 100 coins = extra life
- Power-Up Mushroom: Makes player big, can break bricks
- Star: Temporary invincibility with rainbow effect
- 1-Up: Extra life

PROCEDURAL GENERATION:
- Ground with gaps (wider gaps at higher worlds)
- Floating platforms with ? blocks and bricks
- Pipes (decorative or containing enemies)
- Staircases
- Enemy placement density increases per world
- Coin placement as guidance/reward

AUDIO (8-BIT CHIPTUNE):
- Jump: Rising square wave sweep (150Hz → 400Hz)
- Coin: Two quick notes (B5, E6)
- Stomp: Descending square wave (500Hz → 100Hz)
- Power-Up: Ascending arpeggio
- Death: Descending chromatic scale
- BGM: Looping Mario-style melody (square + triangle waves)

HUD ELEMENTS:
- SCORE (6 digits, top left)
- COINS (with coin icon)
- WORLD (X-Y format)
- TIME (countdown)
- LIVES (remaining)

LEVEL END:
- Flag pole or exit pipe
- Score tally animation
- "WORLD CLEAR" screen
- Next level or game over

CONTROLS:
- WASD or Arrows: Movement
- Space/W/Up: Jump (hold for higher)
- Shift/X: Run (increases speed, jump distance)
- M: Toggle music

TENSION INJECTION:
- Timer creates urgency (lose life if time runs out)
- Enemy density increases per world
- Platform gaps get wider
- Moving platforms become more common
- Power-ups become rarer

REQUIRED ELEMENTS:
- Smooth 60fps scrolling
- Responsive jump with variable height
- Enemy AI with basic patrol behavior
- Collision detection with one-way platforms
- Death animation (player falls off screen)
- Instant restart (<0.5 seconds)
- Local high score tracking
`,

  'Wave Defense': `
DOCTRINE: They come. You hold. Walls fall. Heroes rise.

CORE LOOP (One Mechanic):
- PRIMARY VERB: Defend (place/upgrade defenses, manage resources)
- Enemies path toward objective, you stop them

SESSION STRUCTURE (20 min max):
- Waves 1-3: Build economy, learn paths (CALM)
- Waves 4-7: Resource strain, priority choices (PRESSURE)
- Waves 8-10: Overwhelming force, clutch plays (PANIC)
- Win: All waves cleared | Lose: Objective destroyed

TENSION INJECTION:
- Wave size increases exponentially
- Fast enemies ignore slow defenses
- Flying enemies bypass ground
- Boss waves have time limits

VARIANCE:
- Enemy composition randomized per wave
- Starting resources varied
- Map layout has seed-based variations
- Power-up drops randomized

REQUIRED ELEMENTS:
- Grid or path-based placement
- Multiple tower/defense types (3-5)
- Upgrade system (between waves)
- Enemy health bars
- Wave counter and preview
- Objective health display
`,

  'Resource Panic': `
DOCTRINE: Too much to do. Not enough time/resources. Triage under fire.

CORE LOOP (One Mechanic):
- PRIMARY VERB: Allocate (decide what gets resources NOW)
- Everything is on fire, you have one extinguisher

SESSION STRUCTURE (10-15 min):
- Phase 1: Manageable chaos, learn systems (CALM)
- Phase 2: Two crises at once (PRESSURE)
- Phase 3: Everything failing simultaneously (PANIC)
- End: Collapse or clutch save. Score = survival time + efficiency

TENSION INJECTION:
- Crisis spawn rate increases
- Resource regeneration slows
- Failure cascades (one system failing affects others)
- Audio alarm layering

VARIANCE:
- Crisis types randomized
- Spawn locations varied
- Resource node placement seeded
- Event chains shuffled

REQUIRED ELEMENTS:
- Multiple systems to manage (3-4)
- Clear status indicators (green/yellow/red)
- Limited action points or cooldowns
- Failure state warnings
- Cascade mechanics (failure spreads)
`,

  'Score Chase': `
DOCTRINE: Simple action, infinite skill ceiling, leaderboard glory.

CORE LOOP (One Mechanic):
- PRIMARY VERB: Execute (one simple action, perfected infinitely)
- Examples: timing jumps, aiming shots, chaining combos

SESSION STRUCTURE (5-10 min max):
- Start: Easy multiplier building (CALM)
- Mid: Speed/difficulty scaling (PRESSURE)
- Peak: Frame-perfect execution required (PANIC)
- End: Mistake = run over, final score displayed

TENSION INJECTION:
- Speed increases continuously
- Multiplier decay if too slow
- Near-miss bonuses for risk-taking
- Visual intensity scales with score

VARIANCE:
- Obstacle patterns seeded
- Multiplier locations varied
- Color/theme shifts per run

REQUIRED ELEMENTS:
- Score display (large, prominent)
- Multiplier system
- High score tracking (local)
- Instant restart (one button)
- Clean, readable visuals
- Increasing speed/difficulty
`
};


// ============================================================================
// PROMPT TEMPLATES
// ============================================================================

export const PromptRegistry = {

  QuantizeRequirements: (prefs: UserPreferences) => {

    // Derive authoritative difficulty constraints
    const diffSignature = deriveDifficultySignature(prefs.difficulty);

    return `
You are the Design Director for Dream3DForge, a system that generates SHORT, ADDICTIVE, REPLAYABLE games.

═══════════════════════════════════════════════════════════════════════════════
DREAM3DFORGE DOCTRINE (YOU MUST ENFORCE THIS)
═══════════════════════════════════════════════════════════════════════════════

${DOCTRINE.identity}

THE 5 LAWS:
1. SINGLE-SESSION: ${DOCTRINE.laws.singleSession}
2. ONE MECHANIC: ${DOCTRINE.laws.oneMechanic}
3. FAILURE = TEACHER: ${DOCTRINE.laws.failureTeacher}
4. VARIANCE NOT CONTENT: ${DOCTRINE.laws.varianceNotContent}
5. TENSION CURVE: ${DOCTRINE.laws.tensionCurve}

APPROVED GENRES: ${DOCTRINE.whitelistGenres.join(", ")}

REJECTED CONCEPTS: ${DOCTRINE.blacklistConcepts.join(", ")}

═══════════════════════════════════════════════════════════════════════════════
USER REQUEST
═══════════════════════════════════════════════════════════════════════════════

Genre: ${prefs.genre}
Visual Style: ${prefs.visualStyle}
Camera: ${prefs.cameraPerspective}
Environment: ${prefs.environmentType}
Atmosphere: ${prefs.atmosphere}
Atmosphere: ${prefs.atmosphere}
Pacing: ${prefs.pacing}
Skill Level: ${prefs.skillLevel}
Seed: ${prefs.seed}
Concept: "${prefs.projectDescription || 'Create an engaging game for this genre'}"

═══════════════════════════════════════════════════════════════════════════════
YOUR TASK
═══════════════════════════════════════════════════════════════════════════════

1. CHECK: Does this concept violate doctrine? If so, suggest a compliant alternative.
2. IDENTIFY: What is the ONE primary verb/mechanic?
3. DESIGN: How does the tension curve flow (calm → pressure → panic → resolution)?
4. ENSURE: Session completes in 5-20 minutes max.

OUTPUT (JSON):
{
  "title": "2-4 word catchy name",
  "summary": "One sentence pitch, max 20 words",
  "primaryMechanic": "The ONE thing the player does (e.g., 'dodge', 'shoot+move', 'time')",
  "sessionLength": "Expected minutes (5-20)",
  "tensionCurve": {
    "calm": "What happens in the calm phase",
    "pressure": "What creates pressure",
    "panic": "What creates panic",
    "resolution": "How it ends (death or victory)"
  },
  "coreMechanics": ["3-5 specific mechanics"],
  "visualRequirements": ["3-5 specific visual elements"],
  "gameLoop": {
    "setup": "Spawn player at center, spawn first wave at r=50",
    "action": "Player strafes to avoid shots while aiming at closest target",
    "resolution": "One hit kill. Show 'GAME OVER' + score. Click to restart."
  },
  "controls": {
    "scheme": "Mouse + WASD",
    "mappings": [
       { "input": "W/A/S/D", "action": "Movement" },
       { "input": "Mouse Left", "action": "Fire Primary" }
    ]
  },
  "entities": [
     { "name": "Player", "behavior": "Physics-based char controller", "attributes": "Speed: 10, HP: 1" },
     { "name": "Drone", "behavior": "Chases player", "attributes": "Speed: 5, HP: 1" }
  ],
  "uiLayout": ["Score (Top Left)", "Wave Timer (Top Center)", "Reticle"],
  
  // DEEP DESIGN SPECS (MANDATORY)
  "assets": {
      "textures": [
          { "name": "floor_grid", "type": "grid", "params": { "color1": "#000", "color2": "#0f0" } },
          { "name": "particle_boom", "type": "noise", "params": { "scale": 0.5, "color": "#f00" } }
      ],
      "models": [
          { "name": "PlayerShip", "type": "voxel", "layers": [".A.", "BAB"] },
          { "name": "EnemyDrone", "type": "voxel", "layers": ["X.X", ".X."] }
      ]
  },
  "gameplayRules": {
      "movement": "BaseSpeed=10, DashForce=50, Friction=0.9 (drifty)",
      "combat": "PlayerDamage=1, EnemyHP=3, FireRate=0.2s, BulletSpeed=20",
      "scoring": "Kill=100pts, ComboWindow=1.5s, MultiplierCap=10x"
  },
  
  "doctrineCompliant": true
}

If the concept violates doctrine, set doctrineCompliant to false and include:
{
  "doctrineCompliant": false,
  "violation": "What rule was broken",
  "suggestion": "A compliant alternative concept"
}
`;
  },

  RefineBlueprint: (blueprint: GeneratedGame, iterationGoal: string) => `
You are a Game Designer refining an existing game design document.

CURRENT BLUEPRINT:
${JSON.stringify(blueprint, null, 2)}

USER FEEDBACK / ITERATION GOAL:
"${iterationGoal || "Improve the gameplay loop"}"

TASK:
- Update the blueprint to satisfy the user request.
- Preserve existing content that doesn't need changing.
- Ensure the JSON structure remains valid.
- Maintain authoritative difficulty constraints.
- Do NOT remove existing mechanics unless explicitly requested.

OUTPUT (JSON):
Return the COMPLETE updated blueprint with ALL fields. Include both changed AND unchanged fields.
The response must be a valid JSON object containing the full blueprint specification.

Required top-level fields to include:
- title, summary, coreMechanics, visualRequirements
- gameLoop (setup, action, resolution)
- controls (scheme, mappings)
- gameplayRules, difficulty, progressionSystem
- assets, audioTheme, monetizationHooks
- technicalRequirements, architecture
`,

  ArchitectSystem: (specData: any, prefs: UserPreferences) => `
You are a Software Architect designing a game's technical structure.

    SPECIFICATION:
${JSON.stringify(specData, null, 2)}

    CONSTRAINTS:
    - Platform: ${prefs.platform}
    - Engine: ${prefs.gameEngine}
    - GPU Tier: ${prefs.capabilities.gpuTier}

    TASK: Design the minimal architecture needed.

      OUTPUT(JSON):
    {
      "recommendedEngine": "Engine choice with brief justification",
        "language": "JavaScript",
          "architecture": {
        "style": "Pattern name (e.g., Component, State Machine, ECS)",
          "description": "Why this pattern fits (2 sentences max)",
            "reasoning": {
          "chosen": "Same as style",
            "because": ["reason 1", "reason 2"],
              "rejected": [
                { "model": "OOP", "reason": "Too much state coupling for this genre" },
                { "model": "Functional", "reason": "Performance overhead on mobile" }
              ]
        },
        "nodes": [
          { "name": "SystemName", "type": "system|component|data", "description": "10 words max" }
        ]
      },
      "techStack": [
        { "category": "Category", "name": "Tool", "description": "Why needed" }
      ],
        "prerequisites": [
          { "item": "Requirement", "importance": "Critical|Recommended|Optional" }
        ]
    }

Keep strings SHORT to avoid JSON errors.
`,

  DesignSoundscape: (blueprint: GeneratedGame, prefs: UserPreferences) => `
You are a Procedural Audio Engineer using Web Audio API synthesis.

    GAME: ${blueprint.title}
GENRE: ${prefs.genre}
ATMOSPHERE: ${prefs.atmosphere}
MECHANICS: ${JSON.stringify((blueprint as any).coreMechanics)}

TASK: Create synthesized audio code.

MANDATORY HELPER LIBRARY (THIS IS INJECTED FOR YOU):
${AUDIO_HELPERS}

REQUIREMENTS:
- Use the \`SimpleSequencer\` class provided above for BGM.
- Define catchy, short loops (Mario/Contra style).
- Use 'square' or 'sawtooth' waves for melody, 'triangle' for bass.
- For SFX, use short Oscillator/Gain ramps (Coin, Jump, Explosion).

OUTPUT(JSON):
{
  "description": "Upbeat 8-bit chiptune with driving bassline",
  "backgroundMusic": "function playMusic(ctx) { const seq = new SimpleSequencer(ctx); seq.tempo = 140; seq.addTrack('square', [['C4', 0.5], ['E4', 0.5], ['G4', 0.5]]); seq.start(); return seq; }",
  "soundEffects": [
    { "name": "Jump", "trigger": "Spacebar", "code": "function playJump(ctx) { ... }" }
  ]
}
`,

  // NEW: Split audio generation for lower token usage
  DesignBGM: (blueprint: GeneratedGame, prefs: UserPreferences) => `
You are a Procedural Audio Engineer. Create BACKGROUND MUSIC ONLY.

GAME: ${blueprint.title}
GENRE: ${prefs.genre}
ATMOSPHERE: ${prefs.atmosphere}

MANDATORY HELPER LIBRARY:
${AUDIO_HELPERS}

TASK: Create ONE background music loop using Web Audio API.
- Use SimpleSequencer class
- Short catchy loop (8-16 bars)
- Match the game's atmosphere
- Tempo appropriate for genre

OUTPUT(JSON):
{
  "description": "Dark cyberpunk synthwave with driving bass",
  "backgroundMusic": "function playMusic(ctx) { const seq = new SimpleSequencer(ctx); seq.tempo = 128; seq.addTrack('sawtooth', [['C3',1],['G3',1],['C4',1]]); seq.start(); return seq; }"
}
`,

  DesignSFX: (blueprint: GeneratedGame, prefs: UserPreferences, sfxName: string, trigger: string) => `
You are a Procedural Audio Engineer. Create ONE sound effect.

GAME: ${blueprint.title}
GENRE: ${prefs.genre}
SFX TO CREATE: ${sfxName}
TRIGGER: ${trigger}

TASK: Create Web Audio API code for the "${sfxName}" sound effect.
- Use OscillatorNode and GainNode
- Short duration (0.1-0.5 seconds)
- Immediate playback (no scheduling needed)

OUTPUT(JSON):
{
  "name": "${sfxName}",
  "trigger": "${trigger}",
  "code": "function play${sfxName}(ctx) { const osc = ctx.createOscillator(); const gain = ctx.createGain(); osc.connect(gain); gain.connect(ctx.destination); osc.type = 'square'; osc.frequency.setValueAtTime(440, ctx.currentTime); gain.gain.setValueAtTime(0.3, ctx.currentTime); gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1); osc.start(); osc.stop(ctx.currentTime + 0.1); }"
}
`,

  BuildPrototype: (blueprint: GeneratedGame, prefs: UserPreferences, audioContextStr: string, gpuRules: string) => `
You are an Expert Game Programmer for Dream3DForge.
CRITICAL: You MUST include the full library reference (e.g. 'THREE' for Three.js, 'BABYLON' for Babylon.js) in your code. No placeholders.

═══════════════════════════════════════════════════════════════════════════════
DREAM3DFORGE DOCTRINE(YOU MUST ENFORCE THIS)
═══════════════════════════════════════════════════════════════════════════════

This is a SHORT, ADDICTIVE, REPLAYABLE game(5 - 20 minute sessions).

  THE 5 LAWS TO IMPLEMENT:
1. SINGLE - SESSION: Understand in 30s, fail in 1 - 3min, peak in 20min.NO SAVES.
2. ONE MECHANIC: One primary verb, deepened through play.No feature bloat.
3. FAILURE = TEACHER: Death = instant restart(<1 sec).Show WHY player died.
4. VARIANCE NOT CONTENT: Seeded randomness.NO "new levels" - use modifiers / mixes.
5. TENSION CURVE: MANDATORY escalation pattern in every run.

TENSION CURVE IMPLEMENTATION(CRITICAL):
Your game MUST implement escalating difficulty:

gameTime or waveNumber drives these phases:
- CALM(0 - 20 % of session): Easy enemies, learn controls, build confidence
  - PRESSURE(20 - 60 %): Faster spawns, harder enemies, resource pressure
    - PANIC(60 - 90 %): Screen chaos, split - second decisions, overwhelming odds
      - RESOLUTION: Death(show score / stats) OR victory(rare, feels earned)

Implement via:
- spawnRate *= 1 + (gameTime * 0.1)  // Enemies spawn faster over time
  - enemySpeed *= 1 + (wave * 0.05)    // Enemies get faster each wave
    - Add screen shake that scales with danger
    - Audio tempo / intensity increases with game phase

═══════════════════════════════════════════════════════════════════════════════
GAME SPECIFICATION
═══════════════════════════════════════════════════════════════════════════════
Title: ${blueprint.title}
Summary: ${blueprint.summary}
Primary Mechanic: ${(blueprint as any).primaryMechanic || 'Check coreMechanics'}
Session Length: ${(blueprint as any).sessionLength || '10-15 minutes'}
Mechanics: ${JSON.stringify((blueprint as any).coreMechanics)}
Visuals: ${JSON.stringify((blueprint as any).visualRequirements)}
Tension Design: ${JSON.stringify((blueprint as any).tensionCurve || { calm: 'Easy start', pressure: 'Increasing spawns', panic: 'Overwhelming', resolution: 'Death with score' })}

// RICH BLUEPRINT DETAILS (Use these strict specs)
Game Loop: ${JSON.stringify((blueprint as any).gameLoop)}
Controls: ${JSON.stringify((blueprint as any).controls)}
Entities: ${JSON.stringify((blueprint as any).entities)}
UI Layout: ${JSON.stringify((blueprint as any).uiLayout)}

// ASSET SPECS (Use these values in your Asset Library calls)
Asset Manifest: ${JSON.stringify((blueprint as any).assets || {})}

// GAMEPLAY FORMULAS (Use these exact values)
Rules & Math: ${JSON.stringify((blueprint as any).gameplayRules || {})}

Engine: ${prefs.gameEngine}
Input: ${prefs.capabilities.input}
Visual Style: ${prefs.visualStyle}
Seed: "${prefs.seed}"
Visual Style: ${prefs.visualStyle}
Seed: "${prefs.seed}"
Difficulty: ${prefs.difficulty || 5}/10
Skill Level: ${prefs.skillLevel}
Pacing: ${prefs.pacing}

${gpuRules}

═══════════════════════════════════════════════════════════════════════════════
DIFFICULTY MODIFIERS(Apply These!)
═══════════════════════════════════════════════════════════════════════════════
${(() => {
      const d = prefs.difficulty || 5;
      const spawnMult = 0.5 + (d - 1) * 0.15; // 0.5 at 1, 1.85 at 10
      const speedMult = 0.6 + (d - 1) * 0.1;  // 0.6 at 1, 1.5 at 10
      const damageMult = 0.5 + (d - 1) * 0.17; // 0.5 at 1, 2.0 at 10
      return `
Difficulty Level: ${d} (${d <= 2 ? 'Chill' : d <= 4 ? 'Easy' : d <= 6 ? 'Normal' : d <= 8 ? 'Hard' : 'Nightmare'})

APPLY THESE MULTIPLIERS IN YOUR CODE:
- Base spawn rate multiplier: ${spawnMult.toFixed(2)}x
- Enemy speed multiplier: ${speedMult.toFixed(2)}x  
- Damage to player multiplier: ${damageMult.toFixed(2)}x
- Starting resources: ${(150 - d * 10)}% of normal

Example implementation:
const DIFFICULTY = ${d};
const SPAWN_MULT = ${spawnMult.toFixed(2)};
const SPEED_MULT = ${speedMult.toFixed(2)};
const DAMAGE_MULT = ${damageMult.toFixed(2)};

// Use in your game:
spawnInterval = baseSpawnInterval / SPAWN_MULT;
enemy.speed = baseSpeed * SPEED_MULT;
damage = baseDamage * DAMAGE_MULT;
`;
    })()
    }

═══════════════════════════════════════════════════════════════════════════════
GENRE TEMPLATE
═══════════════════════════════════════════════════════════════════════════════
${GENRE_MECHANICS[prefs.genre] || GENRE_MECHANICS['Arena Shooter']}

═══════════════════════════════════════════════════════════════════════════════
ENGINE: ${prefs.gameEngine}
═══════════════════════════════════════════════════════════════════════════════
${ENGINE_SPECS[prefs.gameEngine] || ENGINE_SPECS[GameEngine.ThreeJS]}

═══════════════════════════════════════════════════════════════════════════════
AUDIO
═══════════════════════════════════════════════════════════════════════════════
${audioContextStr}

═══════════════════════════════════════════════════════════════════════════════
MANDATORY CODE STRUCTURE
═══════════════════════════════════════════════════════════════════════════════

0. ASSET GENERATION LIBRARY (MANDATORY):
// YOU MUST USE THE FUNCTIONS BELOW.
// DO NOT use plain 'new THREE.Color(0xff0000)' for materials.
// DO NOT use plain untextured BoxGeometry for enemies/player.
// Use 'createPixelTexture' for sprites/decals.
// Use 'createGridTexture' for floors/walls.
// Use 'createVoxelModel' for complex 3D shapes (player, enemies).
// Use 'createNeonMaterial' for anything that glows.

${ASSET_HELPERS}

1. CLICK - TO - PLAY OVERLAY(required):
<div id="overlay" > Click to Play </div>

2. SEEDED RANDOM(required for variance):
  class SeededRandom {
    constructor(seed) { this.seed = this.hashCode(String(seed)); }
    hashCode(str) { let h = 0; for (let i = 0; i < str.length; i++) h = ((h << 5) - h) + str.charCodeAt(i) & 0xffffffff; return Math.abs(h) || 1; }
    next() { this.seed = (this.seed * 1103515245 + 12345) & 0x7fffffff; return this.seed / 0x7fffffff; }
    range(a, b) { return a + this.next() * (b - a); }
    int(a, b) { return Math.floor(this.range(a, b + 1)); }
  }
const RNG = new SeededRandom("${prefs.seed}");

3. GAME STATE with tension tracking:
const GameState = {
  isRunning: false,
  gameTime: 0,
  wave: 1,
  score: 0,
  phase: 'calm', // calm, pressure, panic
  spawnRate: 1,
  difficultyMultiplier: 1
};

4. TENSION SYSTEM(required):
function updateTension(delta) {
  GameState.gameTime += delta;
  const progress = Math.min(GameState.gameTime / 300, 1); // 5 min = full intensity

  if (progress < 0.2) GameState.phase = 'calm';
  else if (progress < 0.6) GameState.phase = 'pressure';
  else GameState.phase = 'panic';

  GameState.difficultyMultiplier = 1 + progress * 2; // 1x to 3x
  GameState.spawnRate = 1 + progress * 3; // spawns get faster
}

5. DEATH HANDLING(instant restart):
function die(reason) {
  GameState.isRunning = false;
  showDeathScreen(reason, GameState.score, GameState.gameTime, GameState.wave);
}

function showDeathScreen(reason, score, time, wave) {
  // Show: "You died: [reason]" + Score + Time + Wave
  // "Click to restart" - resets everything, no menus
}

6. GAME LOOP:
function update(delta) {
  if (!GameState.isRunning) return;
  updateTension(delta);
  updatePlayer(delta);
  updateEnemies(delta);
  spawnEnemies(delta); // Use GameState.spawnRate
  checkCollisions();
  updateHUD();
}

7. TELEMETRY:
let frameCount = 0, lastFPS = 0;
setInterval(() => { lastFPS = frameCount; frameCount = 0; }, 1000);
function sendTelemetry(entities) {
  frameCount++;
  window.parent.postMessage({ type: 'forge-telemetry', fps: lastFPS, entities }, '*');
}

8. TOUCH CONTROLS INTEGRATION(CRITICAL FOR MOBILE):
Touch controls are auto - injected.Your code MUST check for them:

  // In your input handling, check touch FIRST:
  function getPlayerInput() {
    let moveX = 0, moveY = 0, fire = false, jump = false;

    // Touch joystick (if available)
    const touch = window.TouchControls?.getMove?.();
    if (touch) {
      moveX = touch.x;  // -1 to 1
      moveY = touch.y;  // -1 to 1
    } else {
      // Keyboard fallback
      if (Input.keys['KeyA'] || Input.keys['ArrowLeft']) moveX -= 1;
      if (Input.keys['KeyD'] || Input.keys['ArrowRight']) moveX += 1;
      if (Input.keys['KeyW'] || Input.keys['ArrowUp']) moveY -= 1;
      if (Input.keys['KeyS'] || Input.keys['ArrowDown']) moveY += 1;
    }

    // Action buttons (combine all inputs)
    fire = Input.mouse?.buttons?.[0] || Input.keys['Space'] || window.TouchControls?.isFire?.() || false;
    jump = Input.keys['Space'] || window.TouchControls?.isJump?.() || false;

    return { moveX, moveY, fire, jump };
  }

// Use in your update loop:
const input = getPlayerInput();
player.velocity.x = input.moveX * player.speed;
player.velocity.z = input.moveY * player.speed;
if (input.fire) shoot();

═══════════════════════════════════════════════════════════════════════════════
CRITICAL REQUIREMENTS
═══════════════════════════════════════════════════════════════════════════════

✓ COMPLETE CODE - No placeholders, no TODOs, no "..."
✓ TENSION CURVE - Difficulty MUST escalate over time
✓ INSTANT DEATH - Die = show score = click = playing again in <1 second
✓ CLEAR FEEDBACK - Player always knows WHY they died
✓ WORKING CONTROLS - Responsive, no input lag
✓ TOUCH SUPPORT - Check window.TouchControls for mobile input
✓ VARIANCE - Use RNG for enemy positions, types, patterns
✓ NO SAVES - Run resets completely on death
✓ NO XP / PROGRESSION - Skill is the only progression

═══════════════════════════════════════════════════════════════════════════════
OUTPUT FORMAT
═══════════════════════════════════════════════════════════════════════════════

{
  "html": "COMPLETE HTML with all code inline",
    "instructions": "Controls in 1-2 lines"
}

The game MUST be playable on BOTH desktop AND mobile.Respect the doctrine.
`,



  RefineCode: (instruction: string, contextCode: string) => `
You are a Senior Game Developer refining a single-file game.

YOUR GOAL: Apply the user's instructions to the game code while maintaining all existing functionality.

USER INSTRUCTION: "${instruction}"

CURRENT CODE:
${contextCode}

CRITICAL RULES:
1. OUTPUT THE **ENTIRE** HTML FILE. Do not output diffs, patches, or snippets.
2. The output must be a valid, runnable single-file HTML game.
3. RETAIN all existing features unless explicitly told to remove them.
4. Ensure the game loop, input handling, and rendering logic remain intact.
5. If adding a feature, integrate it smoothly into the existing architecture.

OUTPUT FORMAT (JSON):
{
  "html": "<!DOCTYPE html>... (THE FULL UPDATED CODE)",
  "instructions": "Updated controls or gameplay instructions if needed",
  "changelog": "Brief summary of changes made"
}
`,

  ValidateCode: (code: string, requirements: string[]) => `
You are a QA Engineer validating a Dream3DForge game against doctrine.

  CODE:
${code.substring(0, 20000)}

DOCTRINE REQUIREMENTS:
1. Session length: 5 - 20 minutes max
2. One primary mechanic(no feature bloat)
3. Death = instant restart(no menus, no saves)
4. Tension curve implemented(difficulty escalates)
5. Seeded randomness for variance
6. No XP / progression systems

ADDITIONAL REQUIREMENTS:
${requirements.map((r, i) => `${i + 1}. ${r}`).join('\n')}

OUTPUT(JSON):
{
  "passed": true / false,
    "doctrineCompliant": true / false,
      "results": [{ "requirement": "...", "status": "PASS/FAIL", "details": "..." }],
        "criticalIssues": ["Must-fix problems"],
          "suggestions": ["Nice-to-have improvements"]
}
`
};

export { ENGINE_SPECS, GENRE_MECHANICS, DOCTRINE };
