/**
 * AI Helpers v2.0
 * Enhanced with retry logic, better parsing, and HTML extraction
 */

/**
 * Parse and sanitize JSON response from AI
 * Handles common issues like markdown code blocks, trailing commas, etc.
 */
export function parseAndSanitize(text: string): any {
  if (!text || text.trim() === '') {
    throw new Error("Empty response from AI");
  }

  let cleaned = text.trim();

  // 1. Strip Markdown Code Blocks
  cleaned = cleaned.replace(/^```json/i, '').replace(/^```/i, '').replace(/```$/i, '');

  // 2. Locate JSON Object Boundaries
  const firstOpen = cleaned.indexOf('{');
  const lastClose = cleaned.lastIndexOf('}');

  if (firstOpen !== -1 && lastClose !== -1 && lastClose > firstOpen) {
    cleaned = cleaned.substring(firstOpen, lastClose + 1);
  }

  // 3. Strip Comments (Safer Mode: Only full line // or block comments)
  cleaned = cleaned.replace(/^\s*\/\/.*$/gm, ''); // Remove line comments
  cleaned = cleaned.replace(/\/\*[\s\S]*?\*\//g, ''); // Remove block comments

  // 4. Fix Common JSON Syntax Errors
  // Remove trailing commas before closing braces/brackets
  cleaned = cleaned.replace(/,\s*([}\]])/g, '$1');

  // 5. Sanitize Control Characters (keep \n \r \t)
  cleaned = cleaned.replace(/[\x00-\x09\x0B\x0C\x0E-\x1F]/g, "");

  try {
    return JSON.parse(cleaned);
  } catch (e: any) {
    // Fallback Level 1: Fix unescaped newlines in strings
    try {
      const fixedNewlines = cleaned.replace(/(?<=:\s*"[^"]*)\n(?=[^"]*")/g, "\\n");
      return JSON.parse(fixedNewlines);
    } catch (e2) { /* ignore */ }

    // Fallback Level 3: Auto-Repair Truncated JSON (Chunk handling)
    try {
      const repaired = repairTruncatedJSON(cleaned);
      return JSON.parse(repaired);
    } catch (e4) { /* ignore */ }

    console.error("JSON Parse Error:", e.message);
    console.error("Failed JSON Body:", cleaned.substring(0, 500) + "...");
    throw new Error(`Failed to parse AI response as JSON: ${e.message}`);
  }
}

/**
 * Attempts to repair truncated JSON by closing strings and balancing braces.
 * Enables parsing of "Large Chunks" that may have been cut off.
 */
function repairTruncatedJSON(json: string): string {
  let repaired = json.trim();

  // 1. Check if we are inside a string
  let inString = false;
  let escaped = false;
  for (let i = 0; i < repaired.length; i++) {
    const char = repaired[i];
    if (char === '"' && !escaped) {
      inString = !inString;
    }
    escaped = (char === '\\' && !escaped);
  }

  // Auto-close string if truncated
  if (inString) {
    repaired += '"';
  }

  // 2. Balance Braces/Brackets
  const stack: string[] = [];
  inString = false;
  escaped = false;

  for (let i = 0; i < repaired.length; i++) {
    const char = repaired[i];

    if (char === '"' && !escaped) inString = !inString;
    escaped = (char === '\\' && !escaped);

    if (!inString) {
      if (char === '{') stack.push('}');
      else if (char === '[') stack.push(']');
      else if (char === '}' || char === ']') {
        const expected = stack.pop();
        if (char !== expected) {
          // Mismatch found - primitive recovery: ignore or assume valid?
          // For now, let's just keep going usually
        }
      }
    }
  }

  // Append missing closers in reverse order
  while (stack.length > 0) {
    repaired += stack.pop();
  }

  return repaired;
}

/**
 * Validate that required fields exist in parsed data
 */
export function validateStructure(data: any, requiredFields: string[], context: string): void {
  if (!data || typeof data !== 'object') {
    throw new Error(`${context}: Response is not an object`);
  }

  const missing = requiredFields.filter(field => {
    const value = data[field];
    return value === undefined || value === null || value === '';
  });

  if (missing.length > 0) {
    throw new Error(`${context}: Missing required fields: ${missing.join(', ')}`);
  }
}

/**
 * Retry a function with exponential backoff
 */
export async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  context: string = "Operation"
): Promise<T> {
  let lastError: Error | null = null;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error: any) {
      lastError = error;
      console.warn(`${context} attempt ${attempt}/${maxRetries} failed:`, error.message);

      if (attempt < maxRetries) {
        // Exponential backoff: 1s, 2s, 4s, etc.
        const delay = Math.pow(2, attempt - 1) * 1000;
        console.log(`Retrying in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }

  throw new Error(`${context} failed after ${maxRetries} attempts: ${lastError?.message}`);
}

/**
 * Extract HTML from a response that might not be valid JSON
 * Useful as fallback when JSON parsing fails
 */
export function extractHTMLFromResponse(text: string): string | null {
  // Try to find HTML content
  const htmlPatterns = [
    // 1. Full Document (Ideal)
    /<!DOCTYPE html>[\s\S]*<\/html>/i,
    /<html[\s\S]*<\/html>/i,

    // 2. Truncated Document (Acceptable)
    /<!DOCTYPE html>[\s\S]*/i,
    /<html[\s\S]*/i,

    // 3. JSON Field Extraction (Escaped)
    /"html"\s*:\s*"([\s\S]*?)(?:"\s*[,}])/i,

    // 4. Fallback: Just the script tag
    /<script[\s\S]*<\/script>/i,
  ];

  for (const pattern of htmlPatterns) {
    const match = text.match(pattern);
    if (match) {
      let html = match[1] || match[0];

      // If extracted from JSON string, unescape it
      if (match[1]) {
        try {
          // Attempt proper JSON string decoding first
          html = JSON.parse(`"${html}"`);
        } catch {
          // Fallback to manual unescape if that fails (e.g. truncated)
          html = html
            .replace(/\\n/g, '\n')
            .replace(/\\r/g, '\r')
            .replace(/\\t/g, '\t')
            .replace(/\\"/g, '"')
            .replace(/\\\\/g, '\\');
        }
      }

      return html;
    }
  }

  return null;
}

/**
 * Compresses code for the AI context window by stripping heavy data assets.
 * This significantly reduces token usage during refinement.
 */
export function compressCodeForContext(code: string): string {
  if (!code) return "";
  let compressed = code;
  // Replace base64 data URIs (images/audio)
  compressed = compressed.replace(/data:[a-z]+\/[a-z]+;base64,[A-Za-z0-9+/=]+/g, '<BASE64_DATA_HIDDEN>');
  // Replace heavy numeric arrays (geometry data) - generic catch for arrays with >10 numbers
  compressed = compressed.replace(/\[(\s*-?\d*\.?\d+,){10,}\s*-?\d*\.?\d+\s*\]/g, '[...GEOMETRY_DATA_HIDDEN...]');
  return compressed;
}

/**
 * Estimate token count (rough approximation)
 */
export function estimateTokenCount(text: string): number {
  // Rough estimate: 1 token ≈ 4 characters for English text
  // Code tends to be slightly more dense
  return Math.ceil(text.length / 3.5);
}
