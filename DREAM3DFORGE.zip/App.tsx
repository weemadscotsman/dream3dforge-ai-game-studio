import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Icons } from './components/Icons';
import { GamePreview } from './components/GamePreview';
import { CodeBlock } from './components/CodeBlock';
import { ArchitectureDiagram } from './components/ArchitectureDiagram';
import { ArchitectureDrawer } from './components/ArchitectureDrawer';
import { runPreflightChecks, CheckResult } from './services/preflightChecks';
import { TokenHistoryGraph } from './components/TokenHistoryGraph';
import { SoundControl } from './components/SoundControl';
import { TemplateSelector } from './components/TemplateSelector';
import { DifficultySlider } from './components/DifficultySlider';
import { VisualPresetPicker } from './components/VisualPresetPicker';
import { generateBlueprint, generatePrototype, refineGame, generateOptimizedSoundscape, refineBlueprint } from './services/geminiService';
import { estimateTokens, formatTokenCount, generateShortHash } from './utils/tokenEstimator';
import { GameTemplate } from './services/templates/gameTemplates';
import { VisualPreset } from './services/templates/visualPresets';
import { SettingsPage } from './components/SettingsPage';
import MatrixRainBackground from './components/MatrixRainBackground';
import { useAutoSave } from './hooks/useAutoSave';
import { StoredProject } from './services/storageService';
import {
    UserPreferences, GeneratedGame, Genre, Platform, SkillLevel, ArchitectureStyle,
    VisualStyle, CameraPerspective, EnvironmentType, Atmosphere, Pacing, TokenTransaction,
    QualityLevel, CapabilityFlags, RefinementSettings, GameEngine
} from './types';
import { motion, AnimatePresence } from 'framer-motion';
// @ts-ignore
import JSZip from 'jszip';
import { ENGINE_VERSION, ENGINE_CODENAME } from './version';
import { speak } from './services/tts';

type GenerationPhase = 'idle' | 'generating_blueprint' | 'blueprint_ready' | 'generating_audio' | 'generating_prototype' | 'complete';

interface ChangeLogItem {
    id: string;
    prompt: string;
    timestamp: number;
}

const App: React.FC = () => {
    const [phase, setPhase] = useState<GenerationPhase>('idle');
    const [isRefining, setIsRefining] = useState(false);
    const [loadingMessage, setLoadingMessage] = useState<string>('');
    const [error, setError] = useState<{ title: string, message: string } | null>(null);
    const [game, setGame] = useState<GeneratedGame | null>(null);
    const [activeTab, setActiveTab] = useState<'play' | 'blueprint' | 'code'>('play');
    const [refinePrompt, setRefinePrompt] = useState('');
    const [changeLog, setChangeLog] = useState<ChangeLogItem[]>([]);

    // Pro Features State
    const [seedLocked, setSeedLocked] = useState(false);
    const [specFrozen, setSpecFrozen] = useState(false);
    const [preflightResults, setPreflightResults] = useState<CheckResult[]>([]);

    // Refinement Tuning State
    const [showRefineSettings, setShowRefineSettings] = useState(false);
    const [refineSettings, setRefineSettings] = useState<RefinementSettings>({
        temperature: 0.7,
        maxOutputTokens: 12000,
        topP: 0.95,
        topK: 40
    });

    // Token Tracking
    const [totalTokens, setTotalTokens] = useState<number>(0);
    const [tokenHistory, setTokenHistory] = useState<TokenTransaction[]>([]);
    const [showTokenGraph, setShowTokenGraph] = useState(false);

    // WebGL Check
    const [webglStatus, setWebglStatus] = useState<boolean | null>(null);
    const abortRef = useRef<boolean>(false);

    // NEW: Template & Preset State
    const [showTemplates, setShowTemplates] = useState(false);
    const [showSettings, setShowSettings] = useState(false);
    const [selectedVisualPreset, setSelectedVisualPreset] = useState<string | null>(null);
    const [difficulty, setDifficulty] = useState(5); // 1-10, default Normal
    const [projectId, setProjectId] = useState<string | null>(null);
    const [globalVolume, setGlobalVolume] = useState(0.7);
    const [isMuted, setIsMuted] = useState(false);

    const [prefs, setPrefs] = useState<UserPreferences>({
        genre: Genre.ArenaShooter,
        platform: Platform.Web,
        gameEngine: GameEngine.ThreeJS,
        skillLevel: SkillLevel.Beginner,
        architectureStyle: ArchitectureStyle.Auto,
        projectDescription: '',
        visualStyle: VisualStyle.Cyberpunk,
        cameraPerspective: CameraPerspective.FirstPerson,
        environmentType: EnvironmentType.Arena,
        atmosphere: Atmosphere.Neon,
        pacing: Pacing.Arcade,
        // Pro Defaults
        seed: Math.random().toString(36).substring(7),
        quality: QualityLevel.Prototype,
        capabilities: {
            gpuTier: 'high',
            input: 'mouse',
            telemetry: true
        },
        difficulty: 5 // Default: Normal
    });

    // Auto-save hook
    const handleProjectLoad = useCallback((project: StoredProject) => {
        setPrefs(project.preferences);
        setGame(project.game);
        setSpecFrozen(project.specFrozen);
        setSeedLocked(project.seedLocked);
        if (project.game?.html) {
            setPhase('complete');
        } else if (project.game?.title) {
            setPhase('blueprint_ready');
        }
    }, []);

    const { save: saveProject } = useAutoSave(
        { preferences: prefs, game, specFrozen, seedLocked },
        projectId,
        setProjectId,
        handleProjectLoad
    );

    useEffect(() => {
        const canvas = document.createElement('canvas');
        const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
        setWebglStatus(!!gl);
    }, []);

    const randomizeSeed = () => {
        if (!seedLocked) {
            setPrefs(p => ({ ...p, seed: Math.random().toString(36).substring(7) }));
        }
    };

    // Handle template selection
    const handleTemplateSelect = (template: GameTemplate) => {
        setPrefs(p => ({
            ...p,
            genre: template.genre,
            visualStyle: template.visualStyle,
            cameraPerspective: template.camera,
            environmentType: template.environment,
            atmosphere: template.atmosphere,
            pacing: template.pacing,
            gameEngine: template.engine,
            projectDescription: template.concept
        }));
        setSelectedVisualPreset(null); // Clear preset since template overrides
        setShowTemplates(false);

        // Auto-set difficulty based on template
        const diffMap = { easy: 3, medium: 5, hard: 7 };
        setDifficulty(diffMap[template.difficulty]);
    };

    // Handle visual preset selection  
    const handleVisualPresetSelect = (preset: VisualPreset) => {
        setPrefs(p => ({
            ...p,
            visualStyle: preset.settings.visualStyle,
            atmosphere: preset.settings.atmosphere,
            ...(preset.settings.environment && { environmentType: preset.settings.environment })
        }));
        setSelectedVisualPreset(preset.id);
    };

    // Handle difficulty change
    const handleDifficultyChange = (level: number) => {
        setDifficulty(level);
        setPrefs(p => ({ ...p, difficulty: level }));
    };

    const handleExport = async () => {
        if (!game || !game.manifest) return;

        const zip = new JSZip();

        // 1. Manifest
        zip.file("forge.manifest.json", JSON.stringify(game.manifest, null, 2));

        // 2. Raw Blueprint (New Feature)
        zip.file("blueprint.json", JSON.stringify(game, null, 2));

        // 3. Source Code
        zip.file("index.html", game.html || "");

        // 4. Documentation
        const readme = `# ${game.title}
      
${game.summary}

## Controls
${game.instructions}

## Audio System
${game.audio ? `**Atmosphere**: ${game.audio.description}\n` : 'No procedural audio generated.'}
${game.audio?.soundEffects?.length ? `### Sound Effects\n${game.audio.soundEffects.map(s => `- **${s.name}**: ${s.trigger}`).join('\n')}` : ''}

## Tech Stack
${game.techStack.map(t => `- ${t.name}: ${t.description}`).join('\n')}

## Project Structure
- **index.html**: The playable game prototype.
- **blueprint.json**: Raw architectural specification (JSON). Use this for seed-based diffing or regenerating the game with the same logic.
- **forge.manifest.json**: Cryptographic proof of generation. Contains the Version, Seed, and Hashes.

## Build Metadata
- Engine Version: ${game.manifest.version}
- Game Engine: ${prefs.gameEngine}
- Seed: ${game.manifest.seed}
- Spec Hash: ${game.manifest.specHash}
- Build Hash: ${game.manifest.buildHash}
- Quality: ${game.manifest.quality}
- Platform: ${game.manifest.platform}
- Timestamp: ${new Date(game.manifest.timestamp).toISOString()}
- Generated by: CANN.ON.AI SYSTEMS
`;
        zip.file("README.md", readme);

        // Generate Zip Blob
        const content = await zip.generateAsync({ type: "blob" });

        // Download
        const url = URL.createObjectURL(content);
        const a = document.createElement('a');
        a.href = url;
        a.download = `dream3d_${game.manifest.seed}_${Date.now()}.zip`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const addToTokenTotal = (action: string, input: any, output: any) => {
        const inp = estimateTokens(input);
        const out = estimateTokens(output);
        const total = inp + out;

        setTotalTokens(prev => {
            const newTotal = prev + total;
            setTokenHistory(h => [...h, {
                id: Date.now().toString() + Math.random().toString().slice(2),
                timestamp: Date.now(),
                action,
                inputTokens: inp,
                outputTokens: out,
                totalTokens: newTotal
            }]);
            return newTotal;
        });
    };

    // Voice Recognition State
    const [isListening, setIsListening] = useState(false);
    const recognitionRef = useRef<any>(null);

    // Initialize Speech Recognition
    useEffect(() => {
        const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

        if (SpeechRecognition) {
            const recognition = new SpeechRecognition();
            recognition.continuous = false;
            recognition.interimResults = true;
            recognition.lang = 'en-US';

            recognition.onstart = () => setIsListening(true);
            recognition.onend = () => setIsListening(false);
            recognition.onerror = (e: any) => {
                console.error("Speech recognition error", e);
                setIsListening(false);
            };

            recognition.onresult = (event: any) => {
                let finalTranscript = '';
                for (let i = event.resultIndex; i < event.results.length; ++i) {
                    if (event.results[i].isFinal) {
                        finalTranscript += event.results[i][0].transcript;
                    }
                }
                if (finalTranscript) {
                    setRefinePrompt(prev => {
                        const spacer = prev && !prev.endsWith(' ') ? ' ' : '';
                        return prev + spacer + finalTranscript;
                    });
                }
            };
            recognitionRef.current = recognition;
        }
    }, []);

    const toggleVoiceInput = () => {
        if (!recognitionRef.current) {
            alert("Voice input not supported in this browser.");
            return;
        }
        if (isListening) {
            recognitionRef.current.stop();
        } else {
            recognitionRef.current.start();
        }
    };

    const handleRefineBlueprint = async () => {
        if (!refinePrompt.trim() || !game) return;

        setIsRefining(true);
        setLoadingMessage("Initializing refinement...");
        try {
            // Use the blueprint generator to refine with status updates
            const result = await refineBlueprint(game, refinePrompt, (status) => {
                setLoadingMessage(status);
            });
            setGame(result);
            setRefinePrompt(""); // Clear input on success
            speak("Blueprint refined successfully.");
        } catch (error: any) {
            console.error("Refinement failed:", error);
            const errorMessage = error?.message || "Unknown error";
            setError({
                title: "Blueprint Refinement Failed",
                message: errorMessage.includes("AI returned empty") 
                    ? "The AI failed to generate changes. Try a more specific request."
                    : `Error: ${errorMessage}. Try again with different wording.`
            });
            speak("Refinement failed.");
        } finally {
            setIsRefining(false);
            setLoadingMessage("");
        }
    };



    const handleGenerateBlueprint = async () => {
        if (!prefs.projectDescription.trim()) {
            setError({
                title: "Missing Description",
                message: "Please describe your game concept before generating."
            });
            speak("Error. Missing project description.");
            return;
        }

        if (specFrozen) return;

        abortRef.current = false;
        setPhase('generating_blueprint');
        setLoadingMessage("Initializing...");
        speak("Initializing Forge Architecture.");
        setError(null);
        setGame(null);
        setChangeLog([]);

        try {
            const blueprint = await generateBlueprint(prefs, (status) => {
                if (!abortRef.current) setLoadingMessage(status);
            });

            if (!abortRef.current) {
                addToTokenTotal("Generate Blueprint", prefs, blueprint);
                setGame(blueprint);
                setPhase('blueprint_ready');
                setActiveTab('blueprint');
                speak("Blueprint generated. Review specifications.");
            }
        } catch (e: any) {
            if (!abortRef.current) {
                setPhase('idle');
                setError({
                    title: "Architecture Failed",
                    message: e.message || "Something went wrong generating the blueprint."
                });
                speak("Architecture generation failed.");
            }
        }
    };

    // ...

    const handleGeneratePrototype = async () => {
        if (!game) return;

        abortRef.current = false;
        setError(null);
        speak("Compiling runtime environment.");

        // PHASE 2.1: AUDIO GENERATION
        setPhase('generating_audio');
        setLoadingMessage("Composing procedural soundtrack...");
        let audioData;

        try {
            audioData = await generateOptimizedSoundscape(game, prefs, (status) => {
                if (!abortRef.current) setLoadingMessage(status);
            });
            if (!abortRef.current) {
                addToTokenTotal("Generate Audio", game, audioData);
            }
        } catch (e: any) {
            console.warn("Audio step failed, continuing...", e);
        }

        if (abortRef.current) return;

        // PHASE 2.2: PROTOTYPE GENERATION
        setPhase('generating_prototype');
        setLoadingMessage("Linking audio to physics engine...");

        try {
            const fullGame = await generatePrototype(game, prefs, audioData, (status) => {
                if (!abortRef.current) setLoadingMessage(status);
            });

            if (!abortRef.current) {
                addToTokenTotal("Build Prototype", game, fullGame);
                setGame(fullGame);
                setPhase('complete');
                setActiveTab('play');
                speak("System Online. Prototype Ready.");
            }
        } catch (e: any) {
            if (!abortRef.current) {
                setPhase('blueprint_ready');
                setError({
                    title: "Prototype Construction Failed",
                    message: e.message || "Failed to generate the game code. Try again."
                });
                speak("Prototype Compilation Failed.");
            }
        }
    };

    const handleRefine = async () => {
        if (!game || !refinePrompt.trim()) return;

        abortRef.current = false;
        const prevPhase = phase;
        setPhase('generating_prototype');
        setLoadingMessage("Analyzing codebase & applying iteration...");
        speak("Applying code refinement.");

        // Optimistically update change log
        const newLogItem = { id: Date.now().toString(), prompt: refinePrompt, timestamp: Date.now() };
        setChangeLog(prev => [newLogItem, ...prev]);

        try {
            // Pass refinement settings to the service
            const result = await refineGame(game, refinePrompt, refineSettings);
            if (!abortRef.current) {
                addToTokenTotal("Refine Code", { game: game.html, prompt: refinePrompt, settings: refineSettings }, result.html);
                setGame(result);
                setRefinePrompt('');
                setPhase('complete');
                setActiveTab('play');
                speak("Refinement complete. Updating systems.");
            }
        } catch (e: any) {
            if (!abortRef.current) {
                setPhase(prevPhase);
                setError({
                    title: "Refinement Failed",
                    message: e.message || "Failed to update the game."
                });
                // Remove failed log item
                setChangeLog(prev => prev.filter(item => item.id !== newLogItem.id));
                speak("Refinement failed.");
            }
        }
    };

    const handleCancel = () => {
        abortRef.current = true;
        if (phase === 'generating_prototype' || phase === 'generating_audio') {
            setPhase('blueprint_ready');
        } else {
            setPhase('idle');
        }
    };

    const handleReset = () => {
        setPhase('idle');
        setGame(null);
        setError(null);
        setTotalTokens(0);
        setTokenHistory([]);
        setChangeLog([]);
        setSpecFrozen(false);
        // Only reset seed if not locked
        if (!seedLocked) {
            setPrefs(p => ({ ...p, seed: Math.random().toString(36).substring(7) }));
        }
    };

    const handlePlatformChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const newPlatform = e.target.value as Platform;
        // Auto-configure input based on platform
        let newInput: 'mouse' | 'touch' | 'gamepad' = 'mouse';
        if (newPlatform === Platform.Mobile) newInput = 'touch';
        if (newPlatform === Platform.Console) newInput = 'gamepad';

        setPrefs(p => ({
            ...p,
            platform: newPlatform,
            capabilities: { ...p.capabilities, input: newInput }
        }));
    };

    // Helper for select inputs
    const SelectField = ({ label, value, onChange, options, disabled }: any) => (
        <div className={disabled ? 'opacity-50 pointer-events-none' : ''}>
            <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-1.5">{label}</label>
            <select
                disabled={disabled}
                title={label}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-md px-2 py-2 text-xs text-zinc-300 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all hover:bg-zinc-900"
                value={value}
                onChange={onChange}
            >
                {Object.values(options).map((opt: any, idx: number) => (
                    <option key={`opt-${idx}-${String(opt)}`} value={opt}>{opt}</option>
                ))}
            </select>
        </div>
    );

    return (
        <div className="min-h-screen bg-black text-zinc-100 selection:bg-indigo-500/30 font-sans flex flex-col">
            <div className="fixed inset-0 z-0 pointer-events-none">
                <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-900/10 rounded-full blur-[120px]" />
                <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-indigo-900/10 rounded-full blur-[120px]" />
            </div>

            {/* Matrix Rain Background Effect */}
            <MatrixRainBackground 
                active={phase === 'generating_blueprint' || phase === 'generating_prototype' || isRefining} 
                statusMessage={loadingMessage}
            />

            {/* Template Selector Modal */}
            <AnimatePresence mode="wait">
                {showTemplates && (
                    <TemplateSelector
                        key="template-selector"
                        onSelect={handleTemplateSelect}
                        onClose={() => setShowTemplates(false)}
                    />
                )}
            </AnimatePresence>
            <AnimatePresence mode="wait">
                {showSettings && (
                    <SettingsPage 
                        key="settings-page"
                        onClose={() => setShowSettings(false)} 
                    />
                )}
            </AnimatePresence>

            <div className="relative z-10 max-w-[1800px] mx-auto px-4 py-6 lg:px-8 flex-1 flex flex-col w-full">

                {/* Header */}
                <header className="shrink-0 mb-6 flex flex-col border-b border-zinc-800 pb-4 relative">
                    <div className="flex justify-between items-end">
                        <div>
                            <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-white to-zinc-400 bg-clip-text text-transparent flex items-center gap-3">
                                <Icons.Box className="w-8 h-8 text-indigo-500" />
                                CANN.ON.AI SYSTEMS
                                <span className="text-xs font-normal text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded">
                                    v{ENGINE_VERSION}
                                </span>
                            </h1>
                            <p className="text-zinc-400 text-sm mt-1">
                                Describe a game. Play it in 60 seconds.
                            </p>
                        </div>
                        <div className="mt-4 md:mt-0 flex items-center gap-4">
                            {/* Sound Control */}
                            <SoundControl
                                onVolumeChange={setGlobalVolume}
                                onMuteChange={setIsMuted}
                            />

                            {game && (
                                <div className="hidden md:flex flex-col items-end">
                                    <span className="text-xs text-zinc-500 uppercase tracking-wider">Project</span>
                                    <span className="font-semibold text-zinc-200">{game.title}</span>
                                </div>
                            )}

                            {/* Token Counter */}
                            <div className="relative">
                                <button
                                    onClick={() => setShowTokenGraph(!showTokenGraph)}
                                    className={`flex flex-col items-end px-3 py-1 border-r border-zinc-800 mr-2 transition-colors rounded hover:bg-zinc-900 ${showTokenGraph ? 'bg-zinc-900' : ''}`}
                                >
                                    <span className="text-[10px] text-zinc-500 uppercase tracking-wider flex items-center gap-1">
                                        Est. Usage
                                        <Icons.Info className="w-3 h-3" />
                                    </span>
                                    <span className="text-xs font-mono font-bold text-indigo-400">{formatTokenCount(totalTokens)} toks</span>
                                </button>
                                <AnimatePresence>
                                    {showTokenGraph && (
                                        <TokenHistoryGraph history={tokenHistory} onClose={() => setShowTokenGraph(false)} />
                                    )}
                                </AnimatePresence>
                            </div>

                            <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-mono border ${webglStatus ? 'bg-green-500/10 border-green-500/20 text-green-400' : 'bg-red-500/10 border-red-500/20 text-red-400'}`}>
                                <Icons.Monitor className="w-3.5 h-3.5" />
                                WebGL {webglStatus ? 'Ready' : 'Unavailable'}
                            </div>

                            {/* Sovereign Mode Badge */}
                            {localStorage.getItem("dream3dforge.settings") && JSON.parse(localStorage.getItem("dream3dforge.settings") || "{}").useSovereignStack && (
                                <motion.div
                                    initial={{ opacity: 0, scale: 0.8 }}
                                    animate={{ opacity: 1, scale: 1 }}
                                    className="flex items-center gap-2 px-3 py-1.5 rounded-full text-[10px] font-bold border border-indigo-500/50 bg-indigo-500/10 text-indigo-400 shadow-[0_0_15px_rgba(99,102,241,0.2)]"
                                >
                                    <Icons.Cpu className="w-3.5 h-3.5 animate-pulse" />
                                    SOVEREIGN STACK ACTIVE
                                </motion.div>
                            )}
                        </div>
                    </div>

                    {/* CONTROL TOOLBAR (PRO FEATURES) */}
                    <div className="mt-4 pt-4 border-t border-zinc-800 flex flex-wrap gap-4 items-center">
                        {/* Quick Start Button */}
                        <button
                            onClick={() => setShowTemplates(true)}
                            className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-medium rounded-lg transition-all shadow-lg shadow-indigo-500/20"
                        >
                            <Icons.Zap className="w-4 h-4" />
                            Quick Start
                        </button>

                        <div className="w-px h-8 bg-zinc-700" />

                        {/* Seed Control */}
                        <div className={`flex items-center gap-2 bg-zinc-900 px-3 py-1.5 rounded border ${seedLocked ? 'border-indigo-500/50 bg-indigo-900/10' : 'border-zinc-800'}`}>
                            <span className="text-[10px] text-zinc-500 uppercase tracking-wider">Seed</span>
                            <input
                                type="text"
                                aria-label="Seed"
                                value={prefs.seed}
                                disabled={seedLocked}
                                onChange={(e) => setPrefs(p => ({ ...p, seed: e.target.value }))}
                                className={`bg-transparent text-xs font-mono text-zinc-300 w-20 outline-none ${seedLocked ? 'opacity-50 cursor-not-allowed' : ''}`}
                            />
                            <button onClick={randomizeSeed} disabled={seedLocked} className={`text-zinc-500 hover:text-indigo-400 ${seedLocked ? 'opacity-50 cursor-not-allowed' : ''}`} title="Randomize Seed">
                                <Icons.Zap className="w-3 h-3" />
                            </button>
                            <div className="w-px h-3 bg-zinc-700 mx-1" />
                            <button
                                onClick={() => setSeedLocked(!seedLocked)}
                                className={`text-[10px] uppercase font-bold tracking-wider ${seedLocked ? 'text-indigo-400' : 'text-zinc-500 hover:text-zinc-300'}`}
                            >
                                {seedLocked ? 'LOCKED' : 'UNLOCKED'}
                            </button>
                        </div>

                        {/* Quality Dropdown */}
                        <div className="flex items-center gap-2 bg-zinc-900 px-3 py-1.5 rounded border border-zinc-800">
                            <span className="text-[10px] text-zinc-500 uppercase tracking-wider">Quality</span>
                            <select
                                aria-label="Quality"
                                value={prefs.quality}
                                onChange={(e: any) => setPrefs(p => ({ ...p, quality: e.target.value }))}
                                className="bg-transparent text-xs text-zinc-300 outline-none w-32"
                            >
                                {Object.values(QualityLevel).map((q, idx) => (
                                    <option key={`quality-${idx}-${q}`} value={q}>{q.split(' ')[0]}</option>
                                ))}
                            </select>
                        </div>

                        {/* Input Mode Indicator */}
                        <div className="flex items-center gap-2 bg-zinc-900 px-3 py-1.5 rounded border border-zinc-800 text-zinc-500">
                            <span className="text-[10px] uppercase tracking-wider">Input</span>
                            <span className="text-xs text-zinc-300 font-mono flex items-center gap-1.5">
                                {prefs.capabilities.input === 'touch' ? <Icons.Mobile className="w-3 h-3" /> :
                                    prefs.capabilities.input === 'gamepad' ? <Icons.Gamepad className="w-3 h-3" /> :
                                        <Icons.Monitor className="w-3 h-3" />}
                                {prefs.capabilities.input.toUpperCase()}
                            </span>
                        </div>

                        {/* Telemetry Toggle */}
                        <button
                            onClick={() => setPrefs(p => ({ ...p, capabilities: { ...p.capabilities, telemetry: !p.capabilities.telemetry } }))}
                            className={`flex items-center gap-2 px-3 py-1.5 rounded border text-xs font-medium transition-colors ${prefs.capabilities.telemetry ? 'bg-indigo-900/20 border-indigo-500/30 text-indigo-400' : 'bg-zinc-900 border-zinc-800 text-zinc-500'}`}
                        >
                            <Icons.Info className="w-3 h-3" />
                            Telemetry
                        </button>

                        <div className="flex-1" />

                        {/* Export Button */}
                        {game && (
                            <button
                                onClick={handleExport}
                                className="flex items-center gap-2 px-3 py-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs rounded border border-zinc-700 transition-colors"
                            >
                                <Icons.Box className="w-3 h-3" />
                                Export ZIP
                            </button>
                        )}

                        {/* Settings Button */}
                        <button
                            onClick={() => setShowSettings(true)}
                            className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white text-xs rounded border border-zinc-800 transition-colors"
                            title="API Configuration"
                        >
                            <Icons.Tools className="w-3 h-3" />
                        </button>

                        {/* Settings Button */}
                        <button
                            onClick={() => setShowSettings(true)}
                            className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-white text-xs rounded border border-zinc-800 transition-colors"
                            title="API Configuration"
                        >
                            <Icons.Tools className="w-3 h-3" />
                        </button>
                    </div>
                </header>

                <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 min-h-0">

                    {/* Left Panel: Configuration */}
                    <div className="lg:col-span-3 flex flex-col gap-4 overflow-y-auto pr-2 custom-scrollbar pb-10">

                        {/* Forge Settings Card */}
                        <div className="bg-zinc-900/80 backdrop-blur-sm border border-zinc-800 rounded-xl p-5 shadow-xl">
                            <div className="flex items-center justify-between mb-4">
                                <h2 className="text-sm font-semibold flex items-center gap-2 text-white uppercase tracking-wider">
                                    <Icons.Tools className="w-4 h-4 text-indigo-400" />
                                    Forge Settings
                                </h2>
                                {phase !== 'idle' && (
                                    <button onClick={handleReset} className="text-xs text-zinc-500 hover:text-zinc-300 underline">
                                        New
                                    </button>
                                )}
                            </div>

                            <div className={`space-y-6 ${specFrozen ? 'opacity-30 pointer-events-none grayscale' : (phase !== 'idle' ? 'opacity-50 pointer-events-none' : '')}`}>

                                {/* Section 1: Core Identity */}
                                <div className="space-y-3 pb-4 border-b border-zinc-800/50">
                                    <h3 className="text-xs font-bold text-zinc-200 flex items-center gap-2">
                                        <Icons.Cpu className="w-3 h-3" /> Core Identity
                                    </h3>
                                    <div className="grid grid-cols-1 gap-3">
                                        {/* GAME ENGINE SELECTOR */}
                                        <SelectField
                                            label="Game Engine"
                                            value={prefs.gameEngine}
                                            options={GameEngine}
                                            onChange={(e: any) => setPrefs(p => ({ ...p, gameEngine: e.target.value }))}
                                            disabled={specFrozen}
                                        />

                                        <SelectField
                                            label="Target Platform"
                                            value={prefs.platform}
                                            options={Platform}
                                            onChange={handlePlatformChange}
                                            disabled={specFrozen}
                                        />
                                        <SelectField
                                            label="Genre"
                                            value={prefs.genre}
                                            options={Genre}
                                            onChange={(e: any) => setPrefs(p => ({ ...p, genre: e.target.value }))}
                                            disabled={specFrozen}
                                        />
                                        <SelectField
                                            label="Skill Level"
                                            value={prefs.skillLevel}
                                            options={SkillLevel}
                                            onChange={(e: any) => setPrefs(p => ({ ...p, skillLevel: e.target.value }))}
                                            disabled={specFrozen}
                                        />
                                        <SelectField
                                            label="Architecture Style"
                                            value={prefs.architectureStyle}
                                            options={ArchitectureStyle}
                                            onChange={(e: any) => setPrefs(p => ({ ...p, architectureStyle: e.target.value }))}
                                            disabled={specFrozen}
                                        />

                                        {/* Difficulty Slider */}
                                        <div className="pt-2">
                                            <DifficultySlider
                                                value={difficulty}
                                                onChange={handleDifficultyChange}
                                                showPresets={true}
                                            />
                                        </div>
                                    </div>
                                </div>

                                {/* Section 2: Visuals & View */}
                                <div className="space-y-3 pb-4 border-b border-zinc-800/50">
                                    <h3 className="text-xs font-bold text-zinc-200 flex items-center gap-2">
                                        <Icons.Monitor className="w-3 h-3" /> Visuals & View
                                    </h3>

                                    {/* Visual Preset Picker */}
                                    <VisualPresetPicker
                                        selected={selectedVisualPreset}
                                        onSelect={handleVisualPresetSelect}
                                        compact={true}
                                    />

                                    <div className="grid grid-cols-1 gap-3">
                                        <SelectField
                                            label="Art Style"
                                            value={prefs.visualStyle}
                                            options={VisualStyle}
                                            onChange={(e: any) => setPrefs(p => ({ ...p, visualStyle: e.target.value }))}
                                            disabled={specFrozen}
                                        />
                                        <SelectField
                                            label="Camera Perspective"
                                            value={prefs.cameraPerspective}
                                            options={CameraPerspective}
                                            onChange={(e: any) => setPrefs(p => ({ ...p, cameraPerspective: e.target.value }))}
                                            disabled={specFrozen}
                                        />
                                        <SelectField
                                            label="Atmosphere / Lighting"
                                            value={prefs.atmosphere}
                                            options={Atmosphere}
                                            onChange={(e: any) => setPrefs(p => ({ ...p, atmosphere: e.target.value }))}
                                            disabled={specFrozen}
                                        />
                                        {/* GPU Tier */}
                                        <div>
                                            <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-1.5">GPU Performance</label>
                                            <select
                                                disabled={specFrozen}
                                                aria-label="GPU Performance"
                                                className="w-full bg-zinc-950 border border-zinc-800 rounded-md px-2 py-2 text-xs text-zinc-300 focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all hover:bg-zinc-900"
                                                value={prefs.capabilities.gpuTier}
                                                onChange={(e: any) => setPrefs(p => ({ ...p, capabilities: { ...p.capabilities, gpuTier: e.target.value } }))}
                                            >
                                                <option value="low">Low (Mobile / iGPU)</option>
                                                <option value="mid">Mid (Laptop / Standard)</option>
                                                <option value="high">High (Desktop / Discrete)</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                {/* Section 3: Gameplay & Layout */}
                                <div className="space-y-3 pb-4 border-b border-zinc-800/50">
                                    <h3 className="text-xs font-bold text-zinc-200 flex items-center gap-2">
                                        <Icons.Layers className="w-3 h-3" /> World Design
                                    </h3>
                                    <div className="grid grid-cols-1 gap-3">
                                        <SelectField
                                            label="Environment Layout"
                                            value={prefs.environmentType}
                                            options={EnvironmentType}
                                            onChange={(e: any) => setPrefs(p => ({ ...p, environmentType: e.target.value }))}
                                            disabled={specFrozen}
                                        />
                                        <SelectField
                                            label="Game Pacing"
                                            value={prefs.pacing}
                                            options={Pacing}
                                            onChange={(e: any) => setPrefs(p => ({ ...p, pacing: e.target.value }))}
                                            disabled={specFrozen}
                                        />
                                    </div>
                                </div>

                                {/* Concept Input */}
                                <div>
                                    <label className="block text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-1.5">Unique Concept Details</label>
                                    <textarea
                                        className="w-full bg-zinc-950 border border-zinc-800 rounded-md px-3 py-2.5 text-xs focus:ring-1 focus:ring-indigo-500 outline-none min-h-[300px] resize-none placeholder-zinc-700 text-zinc-300 custom-scrollbar"
                                        placeholder="Describe specific mechanics, story elements, or unique twists..."
                                        value={prefs.projectDescription}
                                        onChange={(e) => setPrefs(prev => ({ ...prev, projectDescription: e.target.value }))}
                                        disabled={specFrozen}
                                    />
                                </div>
                            </div>

                            {/* ACTIONS */}
                            <div className="mt-6 space-y-3">
                                {/* PHASE 1: IDLE */}
                                {phase === 'idle' && (
                                    <button
                                        onClick={handleGenerateBlueprint}
                                        disabled={specFrozen} // Cannot init if frozen, must use reset
                                        className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 rounded-lg transition-all shadow-lg shadow-indigo-500/20 flex items-center justify-center gap-2 active:scale-95 text-xs tracking-wide uppercase disabled:opacity-50 disabled:cursor-not-allowed"
                                    >
                                        <Icons.Zap className="w-4 h-4" />
                                        Initialize Forge
                                    </button>
                                )}

                                {/* PHASE 2: BLUEPRINT READY */}
                                {phase === 'blueprint_ready' && (
                                    <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}>
                                        {!specFrozen ? (
                                            <div className="space-y-3">
                                                <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3">
                                                    <div className="flex items-center gap-2 text-yellow-400 mb-1">
                                                        <Icons.Info className="w-4 h-4" />
                                                        <span className="text-xs font-bold uppercase">Spec Review Required</span>
                                                    </div>
                                                    <p className="text-[10px] text-yellow-300/70 leading-tight">Review the Blueprint on the right. Freeze it to proceed to compilation.</p>
                                                </div>

                                                {/* Preflight Checks Display */}
                                                {preflightResults.length > 0 && (
                                                    <div className="space-y-1 bg-black/30 p-2 rounded border border-zinc-800">
                                                        {preflightResults.map((check, idx) => (
                                                            <div key={`check-${idx}-${check.id || 'unknown'}`} className="flex items-start gap-2 text-[10px]">
                                                                <span className={check.status === 'hard-fail' ? 'text-red-500 font-bold' : check.status === 'soft-fail' ? 'text-yellow-500 font-bold' : 'text-green-500'}>
                                                                    {check.status === 'hard-fail' ? '❌' : check.status === 'soft-fail' ? '⚠️' : '✓'}
                                                                </span>
                                                                <div className="flex-1">
                                                                    <span className="text-zinc-300 font-medium">{check.name}: </span>
                                                                    <span className={check.status === 'hard-fail' ? 'text-red-400' : check.status === 'soft-fail' ? 'text-yellow-400' : 'text-zinc-500'}>
                                                                        {check.message}
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        ))}
                                                    </div>
                                                )}

                                                <button
                                                    onClick={() => {
                                                        if (!game) return;
                                                        const result = runPreflightChecks(game);
                                                        setPreflightResults(result.checks);

                                                        if (result.passed) {
                                                            setSpecFrozen(true);
                                                        } else {
                                                            setError({
                                                                title: 'Preflight Check Failed',
                                                                message: 'Critical constraints violated. Refine blueprint to resolve Hard Fails.'
                                                            });
                                                        }
                                                    }}
                                                    className={`w-full text-white font-bold py-3 rounded-lg transition-all flex items-center justify-center gap-2 text-xs tracking-wide uppercase ${preflightResults.some(c => c.status === 'hard-fail') ? 'bg-red-900/50 hover:bg-red-900/70 text-red-200' : 'bg-zinc-700 hover:bg-zinc-600'}`}
                                                >
                                                    <Icons.Check className="w-4 h-4" />
                                                    {preflightResults.some(c => c.status === 'hard-fail') ? 'Checks Failed' : 'Approve & Freeze Spec'}
                                                </button>
                                            </div>
                                        ) : (
                                            <div className="space-y-3">
                                                <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3">
                                                    <div className="flex items-center gap-2 text-green-400 mb-1">
                                                        <Icons.Check className="w-4 h-4" />
                                                        <span className="text-xs font-bold uppercase">Spec Locked</span>
                                                    </div>
                                                    <p className="text-[10px] text-green-300/70 leading-tight">Architecture frozen. Hash generated.</p>
                                                </div>
                                                <button
                                                    onClick={handleGeneratePrototype}
                                                    className="w-full bg-green-600 hover:bg-green-500 text-white font-bold py-3 rounded-lg transition-all shadow-lg shadow-green-500/20 flex items-center justify-center gap-2 active:scale-95 text-xs tracking-wide uppercase animate-pulse"
                                                >
                                                    <Icons.Tools className="w-4 h-4" />
                                                    Compile Prototype
                                                </button>
                                            </div>
                                        )}
                                    </motion.div>
                                )}

                                {/* BLUEPRINT REFINEMENT (CHAT BOX) - RESTORED */}
                                {phase === 'blueprint_ready' && !specFrozen && (
                                    <motion.div
                                        initial={{ opacity: 0, y: 10 }}
                                        animate={{ opacity: 1, y: 0 }}
                                        className="bg-zinc-900 border border-zinc-700 rounded-xl p-4 mt-4 shadow-xl"
                                    >
                                        <div className="flex items-center gap-2 mb-3 text-indigo-400">
                                            <Icons.MessageSquare className="w-4 h-4" />
                                            <h3 className="text-xs font-bold uppercase tracking-wider">Refine Blueprint</h3>
                                        </div>

                                        <div className="space-y-3 relative">
                                            {/* Voice Input Indicator */}
                                            {isListening && (
                                                <div className="absolute top-[-30px] left-0 right-0 flex justify-center items-center gap-2 text-red-400 animate-pulse">
                                                    <div className="w-2 h-2 bg-red-500 rounded-full" />
                                                    <span className="text-xs font-bold uppercase tracking-widest">Listening...</span>
                                                </div>
                                            )}

                                            <div className="relative">
                                                <textarea
                                                    className={`w-full bg-black/30 border ${isListening ? 'border-red-500/50 ring-1 ring-red-500/20' : 'border-zinc-700'} rounded-lg pl-3 pr-10 py-2 text-xs text-white placeholder-zinc-500 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none min-h-[60px] resize-none transition-all`}
                                                    placeholder="Ask specifically about mechanics, visuals, or architecture..."
                                                    value={refinePrompt}
                                                    onChange={(e) => setRefinePrompt(e.target.value)}
                                                    onKeyDown={(e) => {
                                                        if (e.key === 'Enter' && !e.shiftKey) {
                                                            e.preventDefault();
                                                            handleRefineBlueprint();
                                                        }
                                                    }}
                                                />
                                                <button
                                                    onClick={toggleVoiceInput}
                                                    className={`absolute top-2 right-2 p-1.5 rounded-md transition-colors ${isListening ? 'bg-red-500/20 text-red-400 hover:bg-red-500/30' : 'text-zinc-500 hover:text-white hover:bg-zinc-800'}`}
                                                    title="Toggle Voice Input"
                                                >
                                                    <Icons.Mic className={`w-4 h-4 ${isListening ? 'animate-pulse' : ''}`} />
                                                </button>
                                            </div>
                                            <div className="flex justify-between items-center">
                                                <span className="text-[10px] text-zinc-500 italic">
                                                    AI reasoning will justify changes.
                                                </span>
                                                <button
                                                    onClick={handleRefineBlueprint}
                                                    disabled={!refinePrompt.trim() || isRefining}
                                                    className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2 px-4 rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 text-[10px] uppercase tracking-wide"
                                                >
                                                    {isRefining ? (
                                                        <>
                                                            <div className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                                            Refining...
                                                        </>
                                                    ) : (
                                                        <>
                                                            <Icons.Sparkles className="w-3 h-3" />
                                                            Update Spec
                                                        </>
                                                    )}
                                                </button>
                                            </div>
                                        </div>
                                    </motion.div>
                                )}

                                {/* LOADING STATES */}
                                {(phase === 'generating_blueprint' || phase === 'generating_prototype' || phase === 'generating_audio') && (
                                    <div className="space-y-2">
                                        <button
                                            disabled
                                            className="w-full bg-zinc-800 text-zinc-400 font-bold py-3 rounded-lg flex items-center justify-center gap-2 text-xs uppercase tracking-wide cursor-not-allowed border border-zinc-700"
                                        >
                                            <div className="w-3.5 h-3.5 border-2 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin" />
                                            {loadingMessage}
                                        </button>
                                        <button
                                            onClick={handleCancel}
                                            className="w-full bg-red-900/20 hover:bg-red-900/40 text-red-400 border border-red-900/30 font-bold py-2 rounded-lg text-[10px] uppercase tracking-wide transition-colors"
                                        >
                                            Abort Sequence
                                        </button>
                                    </div>
                                )}

                                {/* COMPLETE STATE */}
                                {phase === 'complete' && (
                                    <div className="bg-zinc-800/50 rounded-lg p-3 text-center border border-zinc-700">
                                        <p className="text-[10px] font-mono text-zinc-400 uppercase tracking-widest">System Online</p>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Refinement Panel - MOVED outside and made explicitly interactive */}
                        <AnimatePresence>
                            {phase === 'complete' && game && (
                                <motion.div
                                    key="refinement-panel"
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, y: 20 }}
                                    className="relative z-50 bg-zinc-900 border border-zinc-700 rounded-xl p-5 shadow-2xl flex flex-col gap-4"
                                >
                                    <div>
                                        <div className="flex items-center justify-between mb-3">
                                            <h2 className="text-xs font-bold flex items-center gap-2 text-green-400 uppercase tracking-widest">
                                                <Icons.Code className="w-4 h-4" />
                                                Iterate & Polish
                                            </h2>
                                            <button
                                                onClick={() => setShowRefineSettings(!showRefineSettings)}
                                                className={`text-[10px] uppercase font-bold px-2 py-1 rounded transition-colors ${showRefineSettings ? 'bg-zinc-800 text-white' : 'text-zinc-500 hover:text-zinc-300'}`}
                                            >
                                                {showRefineSettings ? 'Hide Tuning' : 'Tune Parameters'}
                                            </button>
                                        </div>

                                        <AnimatePresence>
                                            {showRefineSettings && (
                                                <motion.div
                                                    initial={{ height: 0, opacity: 0 }}
                                                    animate={{ height: 'auto', opacity: 1 }}
                                                    exit={{ height: 0, opacity: 0 }}
                                                    className="overflow-hidden bg-zinc-950/50 rounded-lg border border-zinc-800 mb-3"
                                                >
                                                    <div className="p-3 grid grid-cols-1 gap-3">
                                                        {/* Temperature */}
                                                        <div>
                                                            <div className="flex justify-between items-center mb-1">
                                                                <label className="text-[10px] text-zinc-500 uppercase tracking-wider">Creativity (Temp)</label>
                                                                <span className="text-[10px] font-mono text-zinc-300">{refineSettings.temperature.toFixed(1)}</span>
                                                            </div>
                                                            <input
                                                                type="range"
                                                                aria-label="Temperature"
                                                                min="0" max="2" step="0.1"
                                                                value={refineSettings.temperature}
                                                                onChange={(e) => setRefineSettings({ ...refineSettings, temperature: parseFloat(e.target.value) })}
                                                                className="w-full accent-indigo-500 h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer"
                                                            />
                                                        </div>

                                                        {/* Max Tokens */}
                                                        <div>
                                                            <div className="flex justify-between items-center mb-1">
                                                                <label className="text-[10px] text-zinc-500 uppercase tracking-wider">Response Length</label>
                                                                <span className="text-[10px] font-mono text-zinc-300">
                                                                    {refineSettings.maxOutputTokens >= 65536 ? 'Max (65k)' :
                                                                        refineSettings.maxOutputTokens >= 32000 ? 'Long (32k)' :
                                                                            refineSettings.maxOutputTokens >= 8000 ? 'Medium (8k)' : 'Short (2k)'}
                                                                </span>
                                                            </div>
                                                            <input
                                                                type="range"
                                                                aria-label="Response Length"
                                                                min="2000" max="65536" step="1000"
                                                                value={refineSettings.maxOutputTokens}
                                                                onChange={(e) => setRefineSettings({ ...refineSettings, maxOutputTokens: parseInt(e.target.value) })}
                                                                className="w-full accent-green-500 h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer"
                                                            />
                                                        </div>

                                                        {/* Top P */}
                                                        <div>
                                                            <div className="flex justify-between items-center mb-1">
                                                                <label className="text-[10px] text-zinc-500 uppercase tracking-wider">Guidance (Top P)</label>
                                                                <span className="text-[10px] font-mono text-zinc-300">{refineSettings.topP.toFixed(2)}</span>
                                                            </div>
                                                            <input
                                                                type="range"
                                                                aria-label="Guidance (Top P)"
                                                                min="0.1" max="1" step="0.05"
                                                                value={refineSettings.topP}
                                                                onChange={(e) => setRefineSettings({ ...refineSettings, topP: parseFloat(e.target.value) })}
                                                                className="w-full accent-blue-500 h-1 bg-zinc-800 rounded-lg appearance-none cursor-pointer"
                                                            />
                                                        </div>
                                                    </div>
                                                </motion.div>
                                            )}
                                        </AnimatePresence>

                                        <div className="space-y-3">
                                            <textarea
                                                autoFocus
                                                className="w-full bg-black/50 border border-zinc-700 rounded-lg px-3 py-2 text-xs text-white placeholder-zinc-500 focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none min-h-[80px] resize-none"
                                                placeholder="Describe changes (e.g., 'Make the jump higher', 'Fix the red shader', 'Add a scoring system')..."
                                                value={refinePrompt}
                                                onChange={(e) => setRefinePrompt(e.target.value)}
                                                onKeyDown={(e) => {
                                                    if (e.key === 'Enter' && !e.shiftKey) {
                                                        e.preventDefault();
                                                        handleRefine();
                                                    }
                                                }}
                                            />
                                            <button
                                                onClick={handleRefine}
                                                disabled={!refinePrompt.trim()}
                                                className="w-full bg-green-900/20 hover:bg-green-900/40 text-green-400 border border-green-900/50 hover:border-green-500/50 font-bold py-2 rounded-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 text-[10px] uppercase tracking-wide"
                                            >
                                                <Icons.Code className="w-3 h-3" />
                                                Apply Iteration
                                            </button>
                                        </div>
                                    </div>

                                    {/* Change Log History */}
                                    {changeLog.length > 0 && (
                                        <div className="border-t border-zinc-800 pt-3 max-h-[200px] overflow-y-auto custom-scrollbar">
                                            <h3 className="text-[10px] text-zinc-500 font-bold uppercase tracking-widest mb-2">Change History</h3>
                                            <div className="space-y-2">
                                                {changeLog.map((log) => (
                                                    <div key={log.id} className="bg-zinc-950/50 p-2 rounded border border-zinc-800/50 text-xs">
                                                        <p className="text-zinc-300 italic">"{log.prompt}"</p>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                </motion.div>
                            )}
                        </AnimatePresence>

                        {/* Existing Instructions Card */}
                        {game && game.instructions && (
                            <motion.div
                                initial={{ opacity: 0, y: 10 }}
                                animate={{ opacity: 1, y: 0 }}
                                className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-5"
                            >
                                <div className="flex items-center gap-2 mb-2 text-indigo-400">
                                    <Icons.Gamepad className="w-4 h-4" />
                                    <span className="font-bold text-xs uppercase">Prototype Controls</span>
                                </div>
                                <p className="text-xs text-zinc-400 leading-relaxed whitespace-pre-wrap font-mono">
                                    {game.instructions}
                                </p>
                            </motion.div>
                        )}
                    </div>

                    {/* Right Panel: Content */}
                    <div className="lg:col-span-9 flex flex-col h-[calc(100vh-120px)] sticky top-6">
                        {/* ... (Existing Right Panel Content Unchanged) ... */}
                        <AnimatePresence mode="sync">
                            {error && (
                                <motion.div
                                    key="error-message"
                                    initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                                    className="bg-red-500/10 border border-red-500/20 text-red-200 p-6 rounded-xl flex items-start gap-4 mb-4 shadow-lg shadow-red-900/10"
                                >
                                    <div className="bg-red-500/20 p-2 rounded-lg">
                                        <Icons.Warning className="w-6 h-6 text-red-400" />
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-red-100 mb-1">{error.title}</h4>
                                        <p className="text-sm text-red-300/80 leading-relaxed">{error.message}</p>
                                        <button
                                            onClick={() => setError(null)}
                                            className="mt-3 text-xs font-medium text-red-400 hover:text-red-300 underline underline-offset-2"
                                        >
                                            Dismiss
                                        </button>
                                    </div>
                                </motion.div>
                            )}

                            {/* IDLE SPLASH */}
                            {phase === 'idle' && !error && (
                                <motion.div
                                    key="idle-splash"
                                    initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                                    className="h-full flex flex-col items-center justify-center text-zinc-500 border-2 border-dashed border-zinc-800 rounded-2xl p-12 bg-zinc-900/20"
                                >
                                    <Icons.Layers className="w-20 h-20 mb-6 opacity-20 animate-pulse" />
                                    <h3 className="text-xl font-bold text-zinc-300 mb-2">System Idle</h3>
                                    <p className="text-sm opacity-60 max-w-md text-center">
                                        Configure <span className="text-indigo-400">Core Identity</span>, <span className="text-purple-400">Visuals</span>, and <span className="text-green-400">World Design</span>. <br />
                                        Gemini will architect the solution before manufacturing the prototype.
                                    </p>
                                </motion.div>
                            )}

                            {/* LOADING INDICATOR */}
                            {(phase === 'generating_blueprint' || phase === 'generating_prototype' || phase === 'generating_audio') && !game?.html && (
                                <motion.div
                                    key={`loading-${phase}`}
                                    initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                                    className="h-full flex flex-col items-center justify-center text-zinc-500 border border-zinc-800/50 rounded-2xl p-12 bg-zinc-900/10"
                                >
                                    <div className="w-16 h-16 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin mb-6" />
                                    <h3 className="text-lg font-bold text-zinc-300">
                                        {phase === 'generating_blueprint' ? 'Architecting System...' : phase === 'generating_audio' ? 'Synthesizing Audio...' : 'Forging Prototype...'}
                                    </h3>
                                    <p className="text-xs text-zinc-500 mt-2 font-mono">
                                        {loadingMessage}
                                    </p>
                                </motion.div>
                            )}

                            {game && (
                                <motion.div
                                    key="game-content"
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    className="h-full flex flex-col"
                                >
                                    {/* Tabs */}
                                    <div className="flex items-center gap-2 mb-3">
                                        {game.html && (
                                            <button
                                                onClick={() => setActiveTab('play')}
                                                className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wide transition-all flex items-center gap-2 ${activeTab === 'play'
                                                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                                                    : 'bg-zinc-800 text-zinc-400 hover:text-zinc-200'
                                                    }`}
                                            >
                                                <Icons.Gamepad className="w-4 h-4" />
                                                Prototype
                                            </button>
                                        )}
                                        <button
                                            onClick={() => setActiveTab('blueprint')}
                                            className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wide transition-all flex items-center gap-2 ${activeTab === 'blueprint'
                                                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/20'
                                                : 'bg-zinc-800 text-zinc-400 hover:text-zinc-200'
                                                }`}
                                        >
                                            <Icons.Layers className="w-4 h-4" />
                                            Blueprint
                                        </button>
                                        {game.html && (
                                            <button
                                                onClick={() => setActiveTab('code')}
                                                className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wide transition-all flex items-center gap-2 ${activeTab === 'code'
                                                    ? 'bg-zinc-700 text-white'
                                                    : 'bg-zinc-800 text-zinc-400 hover:text-zinc-200'
                                                    }`}
                                            >
                                                <Icons.Code className="w-4 h-4" />
                                                Source
                                            </button>
                                        )}
                                    </div>

                                    {/* Content Area */}
                                    <div className="flex-1 rounded-2xl overflow-hidden bg-zinc-950 border border-zinc-800 shadow-2xl relative">
                                        {activeTab === 'play' && game.html && (
                                            <GamePreview html={game.html} title={game.title} />
                                        )}

                                        {activeTab === 'blueprint' && (
                                            <div className="absolute inset-0 overflow-y-auto custom-scrollbar p-8">
                                                <div className="max-w-4xl mx-auto space-y-8">

                                                    {/* Executive Summary */}
                                                    <div className="space-y-4">
                                                        <div className="flex justify-between items-start">
                                                            <div>
                                                                <h2 className="text-2xl font-bold text-white">{game.title}</h2>
                                                                <p className="text-zinc-400 leading-relaxed text-lg">{game.summary}</p>
                                                            </div>
                                                            {game.manifest && (
                                                                <div className="flex flex-col gap-2 items-end">
                                                                    <div className="bg-zinc-900 border border-zinc-700 px-3 py-2 rounded text-right">
                                                                        <div className="text-[10px] text-zinc-500 uppercase font-bold">Build Seed</div>
                                                                        <div className="font-mono text-indigo-400 text-xs">{game.manifest.seed}</div>
                                                                    </div>
                                                                    <div className="text-[10px] font-mono text-zinc-600">
                                                                        SPEC HASH: {game.manifest.specHash}
                                                                    </div>
                                                                    <div className="text-[10px] font-mono text-zinc-600">
                                                                        BUILD HASH: {game.manifest.buildHash}
                                                                    </div>
                                                                </div>
                                                            )}
                                                        </div>
                                                        <div className="flex gap-4">
                                                            <div className="bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-3 flex-1">
                                                                <div className="text-xs text-zinc-500 uppercase font-bold mb-1">Recommended Engine</div>
                                                                <div className="text-white font-mono text-lg">{game.recommendedEngine}</div>
                                                            </div>
                                                            <div className="bg-zinc-900 border border-zinc-800 rounded-lg px-4 py-3 flex-1">
                                                                <div className="text-xs text-zinc-500 uppercase font-bold mb-1">Primary Language</div>
                                                                <div className="text-white font-mono text-lg">{game.language}</div>
                                                            </div>
                                                        </div>
                                                    </div>

                                                    {/* Audio Section (New) */}
                                                    {game.audio && (
                                                        <div className="bg-zinc-900/50 border border-zinc-800 p-5 rounded-lg">
                                                            <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                                                                <Icons.Monitor className="w-5 h-5 text-pink-400" />
                                                                Audio Architecture
                                                            </h3>
                                                            <p className="text-sm text-zinc-400 mb-4">{game.audio.description}</p>
                                                            <div className="space-y-2">
                                                                <div className="flex items-center gap-2 bg-zinc-950 p-2 rounded border border-zinc-800">
                                                                    <span className="text-xs bg-pink-500/20 text-pink-400 px-2 py-0.5 rounded font-mono">BGM</span>
                                                                    <span className="text-xs text-zinc-300 font-mono">Procedural Loop Generated</span>
                                                                </div>
                                                                {game.audio.soundEffects.map((sfx, i) => (
                                                                    <div key={i} className="flex items-center gap-2 bg-zinc-950 p-2 rounded border border-zinc-800">
                                                                        <span className="text-xs bg-cyan-500/20 text-cyan-400 px-2 py-0.5 rounded font-mono">SFX</span>
                                                                        <span className="text-sm text-zinc-200 font-bold">{sfx.name}</span>
                                                                        <span className="text-xs text-zinc-500 ml-auto font-mono">{sfx.trigger}</span>
                                                                    </div>
                                                                ))}
                                                            </div>
                                                        </div>
                                                    )}

                                                    {/* Architecture Diagram */}
                                                    <div>
                                                        <div className="mb-6">
                                                            <ArchitectureDrawer game={game} />
                                                        </div>
                                                        <ArchitectureDiagram
                                                            nodes={game.architecture?.nodes || []}
                                                            styleName={game.architecture?.style || 'Unknown'}
                                                        />
                                                        <p className="mt-4 text-zinc-500 text-sm italic">{game.architecture?.description}</p>
                                                    </div>

                                                    {/* Tech Stack */}
                                                    <div>
                                                        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                                                            <Icons.Cpu className="w-5 h-5 text-indigo-400" />
                                                            Tech Stack
                                                        </h3>
                                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                                            {(game.techStack || []).map((item, i) => (
                                                                <div key={i} className="bg-zinc-900 border border-zinc-800 p-4 rounded-lg hover:border-indigo-500/30 transition-colors">
                                                                    <div className="text-xs text-indigo-400 font-mono mb-1">{item.category}</div>
                                                                    <div className="font-bold text-zinc-200 mb-1">{item.name}</div>
                                                                    <div className="text-xs text-zinc-500">{item.description}</div>
                                                                </div>
                                                            ))}
                                                        </div>
                                                    </div>

                                                    {/* Prerequisites */}
                                                    <div>
                                                        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                                                            <Icons.Terminal className="w-5 h-5 text-orange-400" />
                                                            Prerequisites
                                                        </h3>
                                                        <div className="space-y-2">
                                                            {(game.prerequisites || []).map((req, i) => (
                                                                <div key={i} className="flex items-start gap-3 bg-zinc-900/50 p-3 rounded-lg border border-zinc-800/50">
                                                                    <div className={`mt-1.5 w-1.5 h-1.5 rounded-full shrink-0 ${req.importance === 'Critical' ? 'bg-red-500' :
                                                                        req.importance === 'Recommended' ? 'bg-yellow-500' : 'bg-blue-500'
                                                                        }`} />
                                                                    <div className="flex-1">
                                                                        <div className="text-sm font-medium text-zinc-300">{req.item}</div>
                                                                        {req.command && (
                                                                            <code className="block mt-1 text-xs bg-black/40 px-2 py-1 rounded text-zinc-500 font-mono w-fit">
                                                                                {req.command}
                                                                            </code>
                                                                        )}
                                                                    </div>
                                                                </div>
                                                            ))}
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        )}

                                        {activeTab === 'code' && game.html && (
                                            <div className="absolute inset-0 overflow-y-auto custom-scrollbar">
                                                <CodeBlock code={game.html} language="html" />
                                            </div>
                                        )}

                                        {(phase === 'blueprint_ready' || phase === 'generating_prototype' || phase === 'generating_audio') && !game.html && (activeTab === 'play' || activeTab === 'code') && (
                                            <div className="absolute inset-0 flex flex-col items-center justify-center text-zinc-500">
                                                <Icons.Layers className="w-16 h-16 mb-4 opacity-20" />
                                                <p className="text-sm">Blueprint ready. Initialize construction to generate prototype.</p>
                                            </div>
                                        )}
                                    </div>
                                </motion.div>
                            )}
                        </AnimatePresence>
                    </div>
                </div>

                <footer className="shrink-0 mt-4 py-2 border-t border-zinc-900 text-center">
                    <span className="text-[10px] text-zinc-600 font-mono">CANN.ON.AI SYSTEMS v{ENGINE_VERSION}</span>
                </footer>
            </div>
        </div>
    );
};

export default App;