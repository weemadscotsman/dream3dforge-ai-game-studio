# Dream3DForge v2.5.1 "SOVEREIGN"

> **Describe a game. Play it in 60 seconds.**

**Constraint-driven AI game compiler** for arcade-scale, session-based, skill-first games.

---

## 🎮 What Is This?

Dream3DForge generates **playable games** from natural language descriptions. Not demos. Not mockups. **Real games you can play immediately.**

It is **not** a "chat with AI" tool. It is an **AI-orchestrated game engine** that compiles your intent into a deterministic, executable result.

---

## 📚 Documentation

- **[User Guide](docs/USER_GUIDE.md)**: How to use the app, including new AI features.
- **[Architecture](docs/ARCHITECTURE.md)**: Technical breakdown of the AI pipeline.
- **[Changelog](docs/CHANGELOG.md)**: Latest updates (v2.5.1).

---

### The Doctrine

Every game follows these rules:

- **5-20 minute sessions** — No endless grinding
- **One mechanic, deepened** — Simple to learn, hard to master
- **Failure teaches** — Die, learn, retry in seconds
- **Tension curve** — Calm → Pressure → Panic → Resolution

---

## 🚀 Quick Start

### Web (Fastest)

```bash
npm install
npm run dev
```

Open `http://localhost:3003` (or the port Vite assigns)

### AI Configuration

1. **Sovereign Mode**: Run local models via Ollama. No API key needed for local generation.
2. **Cloud Mode**: Use Google Gemini or OpenRouter (GPT-4o, Claude 3.5).
3. Configure via the **Settings (Gear icon)** in-app.

---

## 📱 Build Android APK

```bash
npm run build
npm run cap:android      # First time only
npm run cap:sync
npm run cap:open:android
```

In Android Studio: **Build > Build APK**

---

## 🖥️ Build Windows EXE

```bash
npm run electron:build:win
```

Output: `release/Dream3DForge-2.4.0-win-x64.exe`

---

## 🍎 Build macOS / 🐧 Linux

```bash
npm run electron:build:mac
npm run electron:build:linux
```

---

## ✨ Features

| Feature | Description |
| :--- | :--- |
| **Sovereign Stack** | Support for local LLMs (Ollama) with multi-model orchestration |
| **20+ Game Templates** | From Arena Shooters to Card Battlers and Survival Horror |
| **Visual Presets** | 8 one-click visual themes |
| **Difficulty Slider** | 1-10 with named presets |
| **Mobile Touch Controls** | Auto-injected joystick + buttons |
| **PWA Support** | Install from browser |
| **Auto-Save** | Projects persist locally |
| **Doctrine Enforcement** | AI rejects scope creep |

---

## 📁 Structure

```text
├── App.tsx              # Main app
├── components/          # UI components
├── services/
│   ├── generators/      # AI generation
│   ├── templates/       # Game skeletons, templates, touch controls
│   └── promptRegistry   # AI prompts
├── electron/            # Desktop wrapper
├── capacitor.config.ts  # Mobile config
└── types.ts             # Central type definitions
```

---

## 📜 Version

### v2.5.1 "SOVEREIGN"

- ✅ Integrated Sovereign Mode (Ollama Support)
- ✅ 20+ game templates & skeletons
- ✅ Optimized AI orchestration
- ✅ Mobile-ready (PWA & Capacitor)
- ✅ Type-safe game generation pipeline

---

**Dream3DForge** — *Describe a game. Play it in 60 seconds.*
