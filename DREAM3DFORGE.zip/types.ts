
// ============================================================================
// DREAM3DFORGE TYPES v2.0 - DOCTRINE COMPLIANT
// ============================================================================

/**
 * DOCTRINE-APPROVED GENRES
 * These are the only genres Dream3DForge will generate.
 * All games must be: short-session, skill-first, replayable (5-20 min loops)
 */
export enum Genre {
  ArenaShooter = 'Arena Shooter',
  DodgeSurvival = 'Dodge Survival',
  BulletHell = 'Bullet Hell',
  TacticalGrid = 'Tactical Grid',
  RhythmReaction = 'Rhythm Reaction',
  OneScreenPlatformer = 'One-Screen Platformer',
  WaveDefense = 'Wave Defense',
  ResourcePanic = 'Resource Panic',
  ScoreChase = 'Score Chase',
  Asteroids = 'Asteroids',
  Pong = 'Pong',
  Snake = 'Snake',
  Breakout = 'Breakout',
  Shmup = 'Shmup',
  Racing = 'Racing',
  Flappy = 'Flappy',
  Match3 = 'Match-3',
  Fighting = 'Fighting',
  SurvivalHorror = 'Survival Horror',
  Stealth = 'Stealth',
  Fishing = 'Fishing',
  Golf = 'Golf',
  CardBattler = 'Card Battler'
}

export enum Platform {
  Web = 'Web (WebGL/WebGPU)',
  Desktop = 'Desktop (Windows/Mac/Linux)',
  Mobile = 'Mobile (iOS/Android)',
  Console = 'Console (PS5/Xbox/Switch)'
}

export enum SkillLevel {
  Beginner = 'Beginner',
  Intermediate = 'Intermediate',
  Advanced = 'Advanced'
}

export enum ArchitectureStyle {
  Auto = 'AI Recommended',
  ECS = 'Entity Component System (ECS)',
  OOP = 'Object Oriented (OOP)',
  Functional = 'Functional / Reactive',
  DataOriented = 'Data Oriented Design'
}

// --- NEW DESIGN SETTINGS ---

export enum VisualStyle {
  Minimalist = 'Minimalist / Abstract',
  LowPoly = 'Low Poly / Flat Shaded',
  Cyberpunk = 'Cyberpunk / Neon',
  Retro = 'Retro / Voxel',
  Noir = 'Noir / High Contrast',
  Realistic = 'Realistic (PBR Simulated)',
  Toon = 'Toon / Cel Shaded'
}

export enum CameraPerspective {
  FirstPerson = 'First Person (FPS)',
  ThirdPerson = 'Third Person (Over Shoulder)',
  Isometric = 'Isometric / Top-Down',
  SideScroller = 'Side Scroller (2.5D)',
  Orbital = 'Orbital / God View'
}

export enum EnvironmentType {
  Arena = 'Arena / Enclosed',
  Dungeon = 'Dungeon / Corridors',
  OpenWorld = 'Open Field / Terrain',
  City = 'Urban / Cityscape',
  Space = 'Space / Void',
  Interior = 'Interior / House'
}

export enum Atmosphere {
  Sunny = 'Bright / Sunny',
  Dark = 'Dark / Horror',
  Neon = 'Night / Neon',
  Foggy = 'Misty / Foggy',
  Space = 'Starfield / Void'
}

export enum Pacing {
  Arcade = 'Fast / Arcade',
  Tactical = 'Slow / Tactical',
  Simulation = 'Real-time / Simulation',
  TurnBased = 'Turn-Based / Static'
}

// --- PRO FEATURES ---

export enum GameEngine {
  ThreeJS = 'Three.js (Standard)',
  ThreeJS_WebGPU = 'Three.js (WebGPU Experimental)',
  P5JS = 'p5.js (Creative Coding)',
  BabylonJS = 'Babylon.js (Enterprise 3D)',
  KaboomJS = 'Kaboom.js (2D/Retro)',
  RawWebGL = 'Raw WebGL (No Engine)'
}

export enum QualityLevel {
  Sketch = 'Sketch (Low Detail, Fast)',
  Prototype = 'Prototype (Standard)',
  VerticalSlice = 'Vertical Slice (High Polish)'
}

export interface CapabilityFlags {
  gpuTier: 'low' | 'mid' | 'high';
  input: 'mouse' | 'touch' | 'gamepad';
  telemetry: boolean;
}

export interface UserPreferences {
  // Core
  genre: Genre;
  platform: Platform;
  gameEngine: GameEngine;
  skillLevel: SkillLevel;
  architectureStyle: ArchitectureStyle;
  projectDescription: string;

  // Design & Assets
  visualStyle: VisualStyle;
  cameraPerspective: CameraPerspective;
  environmentType: EnvironmentType;
  atmosphere: Atmosphere;
  pacing: Pacing;

  // Pro Features
  seed: string;
  quality: QualityLevel;
  capabilities: CapabilityFlags;

  // Difficulty (1-10)
  difficulty: number;
  iterationGoal?: string;
}

// DO NOT derive at runtime. This is compile-time authoritative.
export type DifficultySignature = Readonly<{
  reactionWindowMs: number;      // e.g., 400ms -> 150ms
  failurePropagation: number;    // e.g., 1.0 (linear) -> 2.5 (exponential cascade)
  forgivenessFactor: number;     // e.g., 0.8 (generous) -> 0.1 (ruthless)
  enemyVariance: number;         // e.g., 0.2 (predictable) -> 0.9 (chaos)
  aiDirectorAggression: number;   // e.g., 0.1 (sleepy) -> 1.0 (relentless)
}>;

export interface ArchitectureNode {
  name: string;
  type: 'system' | 'component' | 'data' | 'pattern';
  description: string;
}

export interface ArchitectureReasoning {
  chosen: string;
  because: string[];
  rejected: { model: string; reason: string }[];
}

export interface TechStackItem {
  category: string;
  name: string;
  description: string;
  link?: string;
}

export interface Prerequisite {
  item: string;
  command?: string;
  importance: 'Critical' | 'Recommended' | 'Optional';
}

export interface GameAudio {
  description: string;
  backgroundMusic: string; // Javascript code
  soundEffects: {
    name: string;
    trigger: string;
    code: string; // Javascript code
  }[];
}

export interface RefinementSettings {
  temperature: number;      // Creativity (0.0 - 2.0)
  maxOutputTokens: number;  // Length
  topP: number;            // Probability Mass
  topK: number;            // Token Pool Size
}

export interface ForgeManifest {
  version: string;
  timestamp: number;
  seed: string;
  specHash: string; // Hash of the blueprint
  buildHash: string; // Hash of the generated HTML
  platform: Platform;
  quality: QualityLevel;
  parentHash?: string; // For diffing/lineage
}

export interface TensionCurve {
  calm: string;
  pressure: string;
  panic: string;
  resolution: string;
}

export interface GeneratedGame {
  title: string;
  summary: string;

  // Doctrine Fields
  primaryMechanic?: string;
  sessionLength?: string;
  tensionCurve?: TensionCurve;
  doctrineCompliant?: boolean;

  // Playable Prototype
  html?: string;
  instructions?: string;

  // Architectural Advice
  recommendedEngine: string;
  language: string;
  architecture: {
    style: string;
    description: string;
    reasoning?: ArchitectureReasoning;
    nodes: ArchitectureNode[];
  };
  techStack: TechStackItem[];
  prerequisites: Prerequisite[];

  // Core Mechanics
  coreMechanics?: string[];
  visualRequirements?: string[];

  // Rich Breakdown
  gameLoop?: { setup: string; action: string; resolution: string };
  controls?: { scheme: string; mappings: { input: string; action: string }[] };
  entities?: { name: string; behavior: string; attributes: string }[];
  uiLayout?: string[];

  // Deep Design (New)
  assets?: {
    textures: { name: string; type: string; params: any }[];
    models: { name: string; type: string; layers: string[] }[];
  };
  gameplayRules?: {
    movement: string;
    combat: string;
    scoring: string;
  };


  // Assets
  audio?: GameAudio;

  // Metadata
  manifest?: ForgeManifest;
}

export interface TokenTransaction {
  id: string;
  timestamp: number;
  action: string;
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
}

// TELEMETRY & EVENTS
export type EventSource = 'PLAYER' | 'SYSTEM' | 'RNG' | 'AI_DIRECTOR';
export type EventSeverity = 'INFO' | 'WARNING' | 'CRITICAL' | 'FATAL';

export interface GameEvent {
  id: string;
  timestamp: number;
  type: string;
  source: EventSource;
  severity: EventSeverity;
  context: Record<string, any>;
  message: string;
}

export interface TelemetrySession {
  sessionId: string;
  startTime: number;
  events: GameEvent[];
  fpsSamples: number[];
  memorySamples: number[];
}
