// Semantic Versioning for Dream3DForge Engine
// Major.Minor.Patch
export const ENGINE_VERSION = "2.5.2";
export const ENGINE_NAME = "Dream3DForge";
export const ENGINE_CODENAME = "RELEASE";
export const MIN_BLUEPRINT_VERSION = "2.5.0";

export const COMPATIBLE_SCHEMA_VERSIONS = ["1.0.0", "1.1.0", "1.2.0", "2.0.0", "2.1.0", "2.2.0", "2.3.0", "2.4.0", "2.5.0", "2.5.1"];

export const isCompatible = (version: string) => {
    return COMPATIBLE_SCHEMA_VERSIONS.includes(version);
};

