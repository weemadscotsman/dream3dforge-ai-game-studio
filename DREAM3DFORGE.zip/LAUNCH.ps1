# DREAM3DFORGE Launcher
$host.ui.RawUI.WindowTitle = "DREAM3DFORGE v2.5.1 - Game Builder"

Write-Host "==========================================" -ForegroundColor Cyan
Write-Host "   DREAM3DFORGE v2.5.1 - Game Builder" -ForegroundColor Cyan
Write-Host "==========================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Starting development server..." -ForegroundColor Green
Write-Host ""
Write-Host "Once started, open: " -NoNewline
Write-Host "http://localhost:3000/" -ForegroundColor Yellow
Write-Host ""
Write-Host "Press " -NoNewline
Write-Host "Ctrl+C" -ForegroundColor Red -NoNewline
Write-Host " to stop the server"
Write-Host ""

Set-Location "C:\Users\Admin\Desktop\New folder (2)\DREAM3DFORGE"
npm run dev

Write-Host ""
Write-Host "Server stopped. Press any key to exit..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
